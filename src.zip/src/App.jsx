import { useState, useEffect, useRef, useLayoutEffect } from 'react'
import MessageItem from './MessageItem'
import EmojiPicker from './EmojiPicker'
import ServerSidebar from './ServerSidebar'
import ServerView from './ServerView'
import { Compass, Send, Hash, Users, Info, UserPlus, LogOut, Atom, Trash, Pencil, Smile, Reply, X, ArrowDown, ImagePlus, Loader2, MessageCircle, Search, Settings, User, Palette, ShieldAlert, Upload, ArrowLeft, FileText, FileVideo, File, Music, Menu} from 'lucide-react'
import { supabase } from './supabase'
import ReactMarkdown from 'react-markdown' 

import LandingPage from './LandingPage'
import VueParametres from './VueParametres'
import VueExplorateur from './VueExplorateur'
import HubAmis from './HubAmis'
import ZoneSaisie from './ZoneSaisie'
import SidebarDMs from './SidebarDMs';
import ProfilPopover from './ProfilPopover';

import AppProvider from './AppProvider';
import { useUI } from './contexts/UIContext'; // 👈 1. Ajoute l'import

const MobileOverlay = () => {
  const { menuMobileOuvert, fermerMenuMobile } = useUI();
  if (!menuMobileOuvert) return null;
  return <div className="md:hidden fixed inset-0 bg-black/60 z-[100] backdrop-blur-sm" onClick={fermerMenuMobile} />;
};

const BurgerButton = () => {
  const { toggleMenuMobile } = useUI();
  return (
    <button className="md:hidden btn btn-ghost btn-sm btn-circle mr-1" onClick={toggleMenuMobile}>
      <Menu size={20} />
    </button>
  );
};

export default function App() {
  const [nouveauMessage, setNouveauMessage] = useState("");
  const [mentionQuery, setMentionQuery] = useState(null);
  const [mentionIndex, setMentionIndex] = useState(0);
  const [messages, setMessages] = useState([]);
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [isLogin, setIsLogin] = useState(true);
  const [showAuthForm, setShowAuthForm] = useState(false);
  const [isTransitioningAuth, setIsTransitioningAuth] = useState(false); // 👈 État pour l'animation douce

  const basculerVersFormulaire = (estLogin) => {
    setIsTransitioningAuth(true); // Lance la disparition
    setTimeout(() => {
      setIsLogin(estLogin);
      setShowAuthForm(true); // Change d'écran quand c'est invisible
      setIsTransitioningAuth(false); // Lance l'apparition
    }, 200);
  };

  const basculerVersAccueil = () => {
    setIsTransitioningAuth(true); // Lance la disparition
    setTimeout(() => {
      setShowAuthForm(false); // Revient à l'accueil
      setIsTransitioningAuth(false); // Lance l'apparition
    }, 200);
  };

  const [menuContextuel, setMenuContextuel] = useState(null);
  const [menuFermeture, setMenuFermeture] = useState(false);
  const menuFermetureTimeout = useRef(null);

  // 👇 NOUVEAU : Logique de la notice de formatage 👇
  const [showAideFormat, setShowAideFormat] = useState(false);
  const [aideFormatFermeture, setAideFormatFermeture] = useState(false);

  const toggleAideFormat = () => {
    if (showAideFormat) {
      setAideFormatFermeture(true);
      setTimeout(() => { setShowAideFormat(false); setAideFormatFermeture(false); }, 150);
    } else {
      setShowAideFormat(true);
    }
  };

  // 👇 NOUVEAU : LOGIQUE DU GUIDE D'ACCUEIL 👇
  const [showWelcome, setShowWelcome] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const [guideStep, setGuideStep] = useState(0);

  // 👇 NOUVEAU : Suivi des demandes d'amis 👇
  const [demandesEnAttente, setDemandesEnAttente] = useState(0);

  useEffect(() => {
    if (!session) return;

    
  }, [session]);

  // 1. Détecte si c'est la 1ère connexion
  useEffect(() => {
    if (session) {
      const guideFait = localStorage.getItem(`guide_termine_${session.user.id}`);
      if (!guideFait) {
        setTimeout(() => setShowWelcome(true), 1500); // Petit délai pour laisser l'app se charger
      }
    }
  }, [session]);

  // 2. Écoute le signal pour relancer le guide manuellement
  useEffect(() => {
    const handleStartGuide = () => {
      setGuideStep(0);
      setShowGuide(true);
      setVueActive('chat'); // Revenir à l'écran principal pour le fond flouté
    };
    window.addEventListener('start-app-guide', handleStartGuide);
    return () => window.removeEventListener('start-app-guide', handleStartGuide);
  }, []);

  const terminerGuide = () => {
    localStorage.setItem(`guide_termine_${session.user.id}`, 'true');
    setShowGuide(false);
    setGuideStep(0);
  };
  // 👆 FIN LOGIQUE DU GUIDE 👆

  const [salonActuel, setSalonActuel] = useState(() => localStorage.getItem('chat_salon_actuel') || '');
  const salonActuelRef = useRef(salonActuel);
  useEffect(() => { salonActuelRef.current = salonActuel; }, [salonActuel]);
  // 1. On lit la mémoire locale au démarrage
// ── 1. Initialisation avec mémoire ──
  const [vueActive, setVueActive] = useState(() => localStorage.getItem('chat_vue_active') || 'chat');  
  // 2. On sauvegarde chaque changement et on charge les serveurs si besoin
  useEffect(() => { 
    localStorage.setItem('chat_vue_active', vueActive); 
    if (vueActive === 'explorer' && publicServers.length === 0) {
      chargerPublicServers();
    }
  }, [vueActive]);
  const [servers, setServers] = useState([]);
  const [serverActuel, setServerActuel] = useState(null);
  const [serverChannel, setServerChannel] = useState(null);
  const [serverPrecedent, setServerPrecedent] = useState(null);

  

  const activeRoomRef = useRef('');
  useEffect(() => {
    if (serverActuel && serverChannel) {
      activeRoomRef.current = `server-${serverActuel.id}-${serverChannel.id}`;
    } else if (!serverActuel && vueActive === 'chat') {
      activeRoomRef.current = salonActuel;
    } else {
      activeRoomRef.current = '';
    }
  }, [serverActuel, serverChannel, salonActuel, vueActive]);
  const [notifications, setNotifications] = useState(() => {
    const saved = localStorage.getItem('chat_notifs');
    return saved ? JSON.parse(saved) : {};
  });
  useEffect(() => { localStorage.setItem('chat_notifs', JSON.stringify(notifications)); }, [notifications]);

  const [salonsPrives, setSalonsPrives] = useState([]);
  const salonsPrivesRef = useRef(salonsPrives);
  useEffect(() => { salonsPrivesRef.current = salonsPrives; }, [salonsPrives]);

  const [profilPopover, setProfilPopover] = useState(null);
  // Variables de Chargement Global
  const [authLoaded, setAuthLoaded] = useState(false);
  const [serversLoaded, setServersLoaded] = useState(false);
  const [profileLoaded, setProfileLoaded] = useState(false);
  const [friendsLoaded, setFriendsLoaded] = useState(false);
  const [groups, setGroups] = useState([]);
  const [memberMeta, setMemberMeta] = useState({});
  const [metaLoaded, setMetaLoaded] = useState(false);
  // On met à jour la condition de chargement
  const dataLoaded = serversLoaded && profileLoaded && friendsLoaded && metaLoaded;

  // 👇 NOUVELLES VARIABLES POUR LES AMIS 👇
  const [amis, setAmis] = useState([]);
  const [demandesAmis, setDemandesAmis] = useState([]);
  const [ongletAmis, setOngletAmis] = useState('tous'); // 'tous', 'attente', 'ajouter'
  const [rechercheAmi, setRechercheAmi] = useState('');
  const [ajoutAmiLoading, setAjoutAmiLoading] = useState(false);  const [utilisateursEnLigne, setUtilisateursEnLigne] = useState([]);
  const [messageEnEdition, setMessageEnEdition] = useState(null);
  const [texteEdition, setTexteEdition] = useState("");
  const [reponseA, setReponseA] = useState(null); 
  const [afficherNotif, setAfficherNotif] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);
  const fichierInputRef = useRef(null);
  const [fichierPreview, setFichierPreview] = useState(null);

  // 👇 LOGIQUE EXPLORATEUR 👇
  const [publicServers, setPublicServers] = useState([]);
  const [rechercheExplorer, setRechercheExplorer] = useState('');
  const [explorerLoading, setExplorerLoading] = useState(false);


  const chargerPublicServers = async () => {
    setExplorerLoading(true);
    
    // 1. Récupération des serveurs (sans jointure SQL risquée)
    const { data: serversData, error: serversError } = await supabase
      .from('servers')
      .select('*')
      .eq('is_public', true)
      .order('created_at', { ascending: false })
      .limit(50);

    if (serversError) {
      ajouterToast("Erreur de chargement des serveurs", "error");
      setExplorerLoading(false);
      return;
    }

    if (!serversData || serversData.length === 0) {
      setPublicServers([]);
      setExplorerLoading(false);
      return;
    }

    // 2. Récupération manuelle des pseudos des créateurs
    const ownerIds = [...new Set(serversData.map(s => s.owner_id).filter(Boolean))];
    const { data: profilesData } = await supabase
      .from('profiles')
      .select('id, pseudo')
      .in('id', ownerIds);

    // 3. Fusion des données en Javascript (100% fiable)
    const serveursComplets = serversData.map(srv => {
      const createur = profilesData?.find(p => p.id === srv.owner_id);
      return {
        ...srv,
        profiles: createur ? { pseudo: createur.pseudo } : null
      };
    });

    setPublicServers(serveursComplets);
    setExplorerLoading(false);
  };

  const rejoindreServeurPublic = async (srv) => {
    const _pseudoTech = session?.user?.email?.split('@')[0];
    const monPseudoAffiche = monProfil?.pseudo || _pseudoTech;
    const { error } = await supabase.from('server_members').insert({
      server_id: srv.id,
      user_id: session.user.id,
      pseudo: monPseudoAffiche,
      role: 'member'
    });

    if (error && error.code !== '23505') {
      ajouterToast("Erreur : " + error.message, "error");
    } else {
      ajouterToast(`Bienvenue sur ${srv.name} !`);
      // On recharge la liste des serveurs de l'utilisateur
      const { data: memberRows } = await supabase.from('server_members').select('server_id').eq('user_id', session.user.id);
      if (memberRows) {
        const ids = memberRows.map(r => r.server_id);
        const { data: serverData } = await supabase.from('servers').select('*').in('id', ids);
        setServers(serverData || []);
      }
      // On bascule sur le serveur
      const { data: firstCh } = await supabase.from('server_channels').select('*').eq('server_id', srv.id).order('position').limit(1).single();
      setServerActuel(srv);
      setServerChannel(firstCh);
      setVueActive('chat');
    }
  };

  const getFileIcon = (fileType) => {
    if (!fileType) return File;
    if (fileType.startsWith('video/')) return FileVideo;
    if (fileType.startsWith('audio/')) return Music;
    if (fileType === 'application/pdf' || fileType.includes('word') || fileType.includes('document')) return FileText;
    return File;
  };

  const getFileColor = (fileType) => {
    if (!fileType) return 'text-gray-400';
    if (fileType.startsWith('video/')) return 'text-blue-400';
    if (fileType.startsWith('audio/')) return 'text-purple-400';
    if (fileType === 'application/pdf') return 'text-red-400';
    if (fileType.includes('word') || fileType.includes('document')) return 'text-blue-500';
    return 'text-gray-400';
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '';
    if (bytes < 1024) return bytes + ' o';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' Ko';
    return (bytes / (1024 * 1024)).toFixed(1) + ' Mo';
  };

  const GIPHY_KEY = import.meta.env.VITE_GIPHY_KEY || "";
  const [gifOuvert, setGifOuvert] = useState(false);
  const [emojiOuvert, setEmojiOuvert] = useState(false);
  const inputMessageRef = useRef(null);
  const emojiTriggerRef = useRef(null);
  const [gifQuery, setGifQuery] = useState('');
  const [gifResultats, setGifResultats] = useState([]);
  const [gifTendances, setGifTendances] = useState([]);
  const [gifChargement, setGifChargement] = useState(false);
  const [utilisateursEnTrain, setUtilisateursEnTrain] = useState([]);
  const canalTypingRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const conteneurMessagesRef = useRef(null);
  const estEnBasRef = useRef(true);
  const dernierTexteTypingRef = useRef(null);
  const [premierNonLuId, setPremierNonLuId] = useState(null);
  const ligneNonLuRef = useRef(null);
  const [tousCharges, setTousCharges] = useState(false);
  const [chargementAnciens, setChargementAnciens] = useState(false);
  const PAGE_SIZE = 50;
  const tousChargesRef = useRef(false);
  const chargementAnciensRef = useRef(false);
  const isPrependingRef = useRef(false);
  const messagesRef = useRef([]);
  const [rechercheOuverte, setRechercheOuverte] = useState(false);
  const [rechercheQuery, setRechercheQuery] = useState('');
  const [rechercheResultats, setRechercheResultats] = useState([]);
  const [rechercheEnCours, setRechercheEnCours] = useState(false);
  const rechercheRef = useRef(null);
  const messagesRefsMap = useRef({});
  const scrollPositionsSalons = useRef({});
  const emojisDispos = ["👍", "❤️", "😂", "🔥", "👀"];
  const finDesMessagesRef = useRef(null);
  const chargerMessagesAnciensRef = useRef(null);

  const [toasts, setToasts] = useState([]);
  const [estHorsLigne, setEstHorsLigne] = useState(!navigator.onLine);
  useEffect(() => {
    const online = () => setEstHorsLigne(false);
    const offline = () => setEstHorsLigne(true);
    window.addEventListener('online', online);
    window.addEventListener('offline', offline);
    return () => { window.removeEventListener('online', online); window.removeEventListener('offline', offline); };
  }, []);
  const [modalConfirm, setModalConfirm] = useState(null);

  const ajouterToast = (message, type = 'success') => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3500);
  };

  const demanderConfirmation = (message, onConfirm, danger = true) => {
    setModalConfirm({ message, onConfirm, danger });
  };

  const forceScrollRef = useRef(false);

  const [monProfil, setMonProfil] = useState(null);
  const monProfilRef = useRef(null);
  useEffect(() => { monProfilRef.current = monProfil; }, [monProfil]);
  const [profilsCache, setProfilsCache] = useState({});
  const [ongletParametres, setOngletParametres] = useState('profil'); 
  
  const [editPseudo, setEditPseudo] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editStatut, setEditStatut] = useState('en_ligne');
  const [editAvatarUrl, setEditAvatarUrl] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [uploadAvatarEnCours, setUploadAvatarEnCours] = useState(false);
  const [sauvegardeEnCours, setSauvegardeEnCours] = useState(false);
  const avatarInputRef = useRef(null);

  const LISTE_THEMES = ["dark", "light", "cupcake", "synthwave", "retro", "cyberpunk", "dracula", "night", "dim"];
  const [themeActuel, setThemeActuel] = useState(() => localStorage.getItem('chat_theme') || 'dark');

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', themeActuel);
    localStorage.setItem('chat_theme', themeActuel);
  }, [themeActuel]);

  const STATUTS = {
    en_ligne:  { label: 'En ligne',  dot: 'bg-success',  text: 'text-success',  ring: 'ring-success'  },
    occupe:    { label: 'Occupé',    dot: 'bg-warning',  text: 'text-warning',  ring: 'ring-warning'  },
    absent:    { label: 'Absent',    dot: 'bg-error',    text: 'text-error',    ring: 'ring-error'    },
    invisible: { label: 'Invisible', dot: 'bg-gray-400', text: 'text-gray-400', ring: 'ring-gray-400' },
  };

  const estUtilisateurSupprime = (pseudo) => pseudo === '[supprimé]';

  const getStatutEffectif = (pseudoTech, profil) => {
    if (!profil || !utilisateursEnLigne.includes(pseudoTech)) return null;
    if (profil.statut === 'invisible') return null; 
    return profil.statut || 'en_ligne';
  };

  const StatutDot = ({ statut, taille = 'w-2.5 h-2.5' }) => {
    if (!statut) return null;
    return <span className={`${taille} rounded-full border-2 border-base-100 ${STATUTS[statut]?.dot || 'bg-gray-400'} flex-shrink-0`} />;
  };

  const fermerMenuContextuel = () => {
    setMenuFermeture(true);
    menuFermetureTimeout.current = setTimeout(() => { setMenuContextuel(null); setMenuFermeture(false); }, 150);
  };

  const ouvrirMenuContextuel = (e, message) => {
    e.preventDefault();
    if (menuFermetureTimeout.current) clearTimeout(menuFermetureTimeout.current);
    const decalageY = window.innerHeight - e.clientY < 220 ? e.clientY - 220 : e.clientY;
    const decalageX = window.innerWidth - e.clientX < 200 ? e.clientX - 200 : e.clientX;
    setMenuFermeture(false);
    setMenuContextuel({ message, x: decalageX, y: decalageY });
  };

  useEffect(() => {
    if (!menuContextuel) return;
    const handler = (e) => { if (e.button !== 2) fermerMenuContextuel(); };
    window.addEventListener("mousedown", handler);
    return () => window.removeEventListener("mousedown", handler);
  }, [menuContextuel]);

  useEffect(() => { tousChargesRef.current = tousCharges; }, [tousCharges]);
  useEffect(() => { chargementAnciensRef.current = chargementAnciens; }, [chargementAnciens]);
  useEffect(() => { messagesRef.current = messages; }, [messages]);



  const scrollerVersLeBas = () => {
    const c = conteneurMessagesRef.current;
    if (!c) return;
    c.scrollTop = c.scrollHeight;
    setAfficherNotif(false);
    estEnBasRef.current = true;
  };

  const gererScroll = () => {
    if (!conteneurMessagesRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = conteneurMessagesRef.current;
    const estEnBas = scrollHeight - scrollTop - clientHeight < 100;
    estEnBasRef.current = estEnBas;
    if (estEnBas && afficherNotif) setAfficherNotif(false);
    if (scrollTop < 150) chargerMessagesAnciens();
  };
  

  // 👇 AJOUT DE LA MÉMOIRE DE TAILLE DE LISTE 👇
  const prevMessagesLengthRef = useRef(0);

  useEffect(() => {
    if (messages.length === 0) {
      prevMessagesLengthRef.current = 0;
      return;
    }

    // 1. On vérifie si la liste s'est allongée (Nouveau message)
    const estNouveauMessage = messages.length > prevMessagesLengthRef.current;
    prevMessagesLengthRef.current = messages.length;

    // 2. Si c'est juste une modification (réaction, édition), ON NE SCROLLE PAS ! 🛑
    if (!estNouveauMessage) return; 

    const dernierMessage = messages[messages.length - 1];
    const monPseudoTech = session?.user?.email?.split('@')[0];
    
    if (forceScrollRef.current) return;
    if (isPrependingRef.current) return;

    if (estEnBasRef.current || dernierMessage?.username === monPseudoTech) {
      requestAnimationFrame(() => {
        const c = conteneurMessagesRef.current;
        if (c) { c.scrollTop = c.scrollHeight; estEnBasRef.current = true; setAfficherNotif(false); }
      });
    } else {
      setAfficherNotif(true);
    }
  }, [messages, session]);

  const formaterDateSeparateur = (dateISO) => {
    const d = new Date(dateISO), auj = new Date(), hier = new Date();
    hier.setDate(auj.getDate() - 1);
    if (d.toDateString() === auj.toDateString()) return "Aujourd'hui";
    if (d.toDateString() === hier.toDateString()) return "Hier";
    return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  };

  const getNomSalonAffichage = () => {
    if (salonActuel.startsWith('dm_')) {
      const monPseudoTech = session?.user?.email?.split('@')[0];
      const [, u1, u2] = salonActuel.split('_');
      const autrePseudoTech = u1 === monPseudoTech ? u2 : u1;
      const autrePseudoAffiche = profilsCache[autrePseudoTech]?.pseudo || autrePseudoTech;
      return `@ ${autrePseudoAffiche}`;
    }
    return `# ${salonActuel}`;
  };

  const changerSalon = (nouveauSalon) => {
    if (messages.length > 0)
      localStorage.setItem(`chat_dernier_lu_${salonActuel}`, messages[messages.length - 1].id.toString());
    
    setPremierNonLuId(null);
    setTousCharges(false);
    setGifOuvert(false);
    setEmojiOuvert(false);
    if (fichierPreview) { URL.revokeObjectURL(fichierPreview.url); setFichierPreview(null); }
    setSalonActuel(nouveauSalon);
    localStorage.setItem('chat_salon_actuel', nouveauSalon);
    setNotifications(prev => ({ ...prev, [nouveauSalon]: 0 }));
    setUtilisateursEnTrain([]);
    setVueActive('chat'); 
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadAvatarEnCours(true);
    const fileExt = file.name.split('.').pop();
    const filePath = `${session.user.id}/${Date.now()}.${fileExt}`; 
    
    const { error: uploadError } = await supabase.storage.from('avatars').upload(filePath, file);
    if (uploadError) {
      ajouterToast("Erreur upload : " + uploadError.message, "error");
    } else {
      const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(filePath);
      setEditAvatarUrl(publicUrl);
    }
    setUploadAvatarEnCours(false);
  };

  const sauvegarderParametres = async () => {
    if (!session) return;
    setSauvegardeEnCours(true);
    const pseudoTech = session.user.email.split('@')[0];
    const newPseudo = editPseudo.trim() || pseudoTech;
    
    const payload = { 
      id: session.user.id, 
      pseudo: newPseudo, 
      bio: editBio, 
      statut: editStatut, 
      avatar_url: editAvatarUrl,
      updated_at: new Date().toISOString() 
    };
    await supabase.from('profiles').upsert(payload);
    
    if (newPseudo !== monProfil?.pseudo) {
       await supabase.from('messages').update({ username: newPseudo }).eq('username', monProfil?.pseudo || pseudoTech);
       await supabase.from('reactions').update({ username: newPseudo }).eq('username', monProfil?.pseudo || pseudoTech);
    }

    const updated = { ...monProfil, ...payload };
    setMonProfil(updated);
    setProfilsCache(prev => ({ ...prev, [pseudoTech]: updated }));
    setSauvegardeEnCours(false);
    ajouterToast("Profil sauvegardé ✓");
  };

  const changerMotDePasse = async () => {
    if(editPassword.length < 6) return ajouterToast("6 caractères minimum requis.", 'error');
    setSauvegardeEnCours(true);
    const { error } = await supabase.auth.updateUser({ password: editPassword });
    setSauvegardeEnCours(false);
    if(error) ajouterToast("Erreur : " + error.message, 'error');
    else { ajouterToast("Mot de passe mis à jour ✓"); setEditPassword(""); }
  };

  const supprimerMonCompte = async () => {
    // L'email est banni et le compte supprimé DANS la fonction SQL (atomique)
    if (monProfil?.avatar_url) {
      const path = monProfil.avatar_url.split('/avatars/')[1];
      if (path) await supabase.storage.from('avatars').remove([path]);
    }
    const { error } = await supabase.rpc('delete_my_account');
    if (error) {
      ajouterToast("Erreur lors de la suppression : " + error.message, 'error');
      return;
    }
    ajouterToast("Compte supprimé définitivement.");
    setTimeout(async () => {
      await supabase.removeAllChannels();
      await supabase.auth.signOut();
      window.location.reload();
    }, 1200);
  };

  const ouvrirParametres = () => {
    const pseudoTech = session.user.email.split('@')[0];
    setEditPseudo(monProfil?.pseudo || pseudoTech);
    setEditBio(monProfil?.bio || '');
    setEditStatut(monProfil?.statut || 'en_ligne');
    setEditAvatarUrl(monProfil?.avatar_url || '');
    setOngletParametres('profil');
    setVueActive('parametres'); 
  };

  const supprimerSalonDM = async (contact) => {
    const monPseudoTech = session?.user?.email?.split('@')[0];
    const room = `dm_${[monPseudoTech, contact].sort().join('_')}`;
    const nouveauxContacts = salonsPrives.filter(c => c !== contact);
    setSalonsPrives(nouveauxContacts);
    await supabase.from('profiles').update({ dm_contacts: nouveauxContacts }).eq('id', session.user.id);
    if (salonActuel === room) changerSalon('');
  };

  const gererClicProfil = async (e, username) => {
    const monPseudoAffiche = monProfil?.pseudo || session?.user?.email?.split('@')[0];
    if (username === monPseudoAffiche || username === session?.user?.email?.split('@')[0]) {
      ouvrirParametres();
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    let top = rect.bottom + 5;
    if (top + 220 > window.innerHeight) top = rect.top - 225;
    
    let pseudoTechKey = username;
    Object.keys(profilsCache).forEach(key => {
      if(profilsCache[key].pseudo === username) pseudoTechKey = key;
    });

    setProfilPopover({ username: pseudoTechKey, displayUsername: username, top, left: Math.max(10, rect.left), profil: profilsCache[pseudoTechKey] });
  };

  const demarrerDM = async (autrePseudoTech) => {
    const monPseudoTech = session?.user?.email?.split('@')[0];
    if (autrePseudoTech === monPseudoTech) return;
    const room = `dm_${[monPseudoTech, autrePseudoTech].sort().join('_')}`;
    if (!salonsPrives.includes(autrePseudoTech)) {
      const nouveauxContacts = [...salonsPrives, autrePseudoTech];
      setSalonsPrives(nouveauxContacts);
      await supabase.from('profiles').update({ dm_contacts: nouveauxContacts }).eq('id', session.user.id);
    }
    
    changerSalon(room);

    // 👇 LE CORRECTIF EST ICI 👇 : On force l'application à quitter le serveur pour afficher les DMs
    setServerActuel(null); 
    localStorage.removeItem('chat_server_id');
    localStorage.removeItem('chat_channel_id');
    // 👆 ──────────────────── 👆

    setProfilPopover(null);
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setAuthLoaded(true);
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      
      if (!s) {
        // 🧹 NETTOYAGE COMPLET DE LA MÉMOIRE (Logout)
        setShowAuthForm(false); // 👈 ON FORCE LE RETOUR À LA LANDING PAGE
        setServers([]);
        setGroups([]);
        setMemberMeta({});
        setServerActuel(null);
        setServerChannel(null);
        setSalonsPrives([]);
        setMessages([]);
        setNotifications({});
        setUtilisateursEnLigne([]);
        setProfilsCache({});
        setMonProfil(null);
        setUtilisateursEnTrain([]);
        setSalonActuel('');

        // Nettoyage du localStorage pour éviter les conflits entre comptes
        localStorage.removeItem('chat_server_id');
        localStorage.removeItem('chat_channel_id');
        localStorage.removeItem('chat_salon_actuel');

        // Réinitialisation des capteurs de chargement
        setServersLoaded(false);
        setProfileLoaded(false);
        setFriendsLoaded(false);
        setMetaLoaded(false);
        setAuthLoaded(true);
      }
    });
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) return;
    const pseudoTech = session.user.email.split('@')[0];

    // Fonction utilitaire pour attendre le chargement d'une image
    const preloadImage = (url) => {
      if (!url) return Promise.resolve();
      return new Promise((resolve) => {
        const img = new Image();
        img.src = url;
        img.onload = resolve;
        img.onerror = resolve; // On résout quand même en cas d'erreur pour ne pas bloquer le site
      });
    };

    (async () => {
      // 1. Charger Serveurs + Groupes + Meta en parallèle
      const [resServers, resGroups, resMems] = await Promise.all([
        supabase.from('server_members').select('server_id').eq('user_id', session.user.id),
        supabase.from('server_groups').select('*').eq('user_id', session.user.id).order('position'),
        supabase.from('server_members').select('server_id, group_id, position').eq('user_id', session.user.id)
      ]);

      if (resServers.data?.length) {
        const ids = resServers.data.map(r => r.server_id);
        const { data: serverData } = await supabase.from('servers').select('*').in('id', ids);
        setServers(serverData || []);
        
        // Pré-charger les icônes des serveurs
        await Promise.all((serverData || []).map(s => preloadImage(s.icon_url)));

        // Gestion de la navigation mémorisée
        // Gestion de la navigation mémorisée (Serveur + Salon)
        const savedSrvId = localStorage.getItem('chat_server_id');
        const savedChId = localStorage.getItem('chat_channel_id');
        
        if (savedSrvId) {
          const srv = serverData.find(s => s.id === savedSrvId);
          if (srv) {
            setServerActuel(srv);
            // On restaure le salon spécifique s'il existe
            if (savedChId) {
                      const { data: ch } = await supabase.from('server_channels').select('*').eq('id', savedChId).eq('server_id', srv.id).single();
                      if (ch) {
                        setServerChannel(ch);
                      } else {
                        localStorage.removeItem('chat_channel_id'); // 🧹 Salon fantôme, on nettoie !
                      }
                    }
          }
        }
      }

      // 2. Traiter les Groupes et Meta
      setGroups(resGroups.data || []);
      const meta = {};
      (resMems.data || []).forEach(m => { meta[m.server_id] = { group_id: m.group_id ?? null, position: m.position ?? 999 }; });
      setMemberMeta(meta);

      setServersLoaded(true);
      setMetaLoaded(true); // ✅ Tout le squelette est prêt
    })();

    (async () => {
      // On utilise maybeSingle() pour éviter une erreur si le profil n'existe pas encore
      const { data } = await supabase.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
      
      let monProfilActuel = data;

      if (data) {
        setMonProfil(data);
        setProfilsCache(prev => ({ ...prev, [pseudoTech]: data }));
        await preloadImage(data.avatar_url); // ✅ On attend l'avatar
      } else {
        // 👇 LE CORRECTIF EST ICI : Création automatique du profil (Acte de naissance !) 👇
        const payload = { id: session.user.id, pseudo: pseudoTech, bio: '', statut: 'en_ligne' };
        const { data: newProfile } = await supabase.from('profiles').upsert(payload).select().single();
        if (newProfile) {
          monProfilActuel = newProfile;
          setMonProfil(newProfile);
          setProfilsCache(prev => ({ ...prev, [pseudoTech]: newProfile }));
        }
      }
      
      // On charge les profils du reste du monde dans le cache
      const { data: allProfiles } = await supabase.from('profiles').select('*');
      if (allProfiles) {
        const cacheMap = {};
        allProfiles.forEach(p => { cacheMap[p.pseudo] = p; });
        // On fusionne tout, en s'assurant de garder notre propre profil fraîchement créé !
        setProfilsCache(prev => ({ ...cacheMap, ...prev, [pseudoTech]: monProfilActuel }));
      }
      
      setProfileLoaded(true);
    })();
  }, [session]);

  useEffect(() => {
    if (!session) return;
    const monPseudoTech = session.user.email.split('@')[0];

    const chargerHistoriqueDMs = async () => {
      const { data: profil } = await supabase.from('profiles').select('dm_contacts').eq('id', session.user.id).single();
      if (profil && Array.isArray(profil.dm_contacts)) {
        setSalonsPrives(profil.dm_contacts);
      } else {
        // Rétrocompatibilité : on cherche dans les anciens messages si le profil n'a pas de contacts
        const { data } = await supabase.from('messages').select('room').ilike('room', 'dm_%');
        if (data) {
          const mesDMs = [...new Set(data.map(d => d.room).filter(r => r.split('_').includes(monPseudoTech)))];
          const contacts = [...new Set(mesDMs.map(room => {
            const [, u1, u2] = room.split('_');
            return u1 === monPseudoTech ? u2 : u1;
          }))];
          setSalonsPrives(contacts);
          // On sauvegarde ces contacts dans le nouveau système
          if (contacts.length > 0) {
            await supabase.from('profiles').update({ dm_contacts: contacts }).eq('id', session.user.id);
          }
        }
      }
    };
    chargerHistoriqueDMs();

    const radarGlobal = supabase.channel('radar-global')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, ({ new: msg }) => {
        const monPseudoAffiche = monProfil?.pseudo || monPseudoTech;
        if (msg.username === monPseudoAffiche || msg.username === monPseudoTech) return;
        if (msg.room !== activeRoomRef.current) { // 👈 On utilise la nouvelle référence globale
          if (msg.room.startsWith('dm_')) {
            const parts = msg.room.split('_');
            if (parts.includes(monPseudoTech)) {
              const autre = parts[1] === monPseudoTech ? parts[2] : parts[1];
              if (!salonsPrivesRef.current.includes(autre)) {
                const nouveauxContacts = [...salonsPrivesRef.current, autre];
                setSalonsPrives(nouveauxContacts);
                supabase.from('profiles').update({ dm_contacts: nouveauxContacts }).eq('id', session.user.id);
              }
              setNotifications(prev => ({ ...prev, [msg.room]: (prev[msg.room] || 0) + 1 }));
            }
          } else {
            setNotifications(prev => ({ ...prev, [msg.room]: (prev[msg.room] || 0) + 1 }));
          }
        }
      }).subscribe();

    const canalPresence = supabase.channel('presence-globale', { config: { presence: { key: monPseudoTech } } });
    canalPresence
      .on('presence', { event: 'sync' }, () => {
        setUtilisateursEnLigne(Object.keys(canalPresence.presenceState()));
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') await canalPresence.track({ online_at: new Date().toISOString() });
      });

    const canalBroadcast = supabase.channel('broadcast-typing-global');
    canalBroadcast
      .on('broadcast', { event: 'typing' }, ({ payload }) => {
        const { pseudo, salon, typing } = payload;
        const monPseudoAffiche = monProfilRef.current?.pseudo || monPseudoTech;
        if (!pseudo || pseudo === monPseudoAffiche || pseudo === monPseudoTech || salon !== salonActuelRef.current) return;
        clearTimeout(window[`typing_timeout_${pseudo}`]);
        if (typing) {
          setUtilisateursEnTrain(prev => prev.includes(pseudo) ? prev : [...prev, pseudo]);
          window[`typing_timeout_${pseudo}`] = setTimeout(() => {
            setUtilisateursEnTrain(prev => prev.filter(p => p !== pseudo));
          }, 3000);
        } else {
          setUtilisateursEnTrain(prev => prev.filter(p => p !== pseudo));
        }
      })
      .subscribe((status) => { if (status === 'SUBSCRIBED') canalTypingRef.current = canalBroadcast; });

    const canalServers = supabase.channel('realtime-servers')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'server_members', filter: `user_id=eq.${session.user.id}` }, async ({ new: row }) => {
        const { data } = await supabase.from('servers').select('*').eq('id', row.server_id).single();
        if (data) setServers(prev => prev.find(s => s.id === data.id) ? prev : [...prev, data]);
      })
      // 👇 AJOUTE CETTE ÉCOUTE DE SUPPRESSION 👇
      .on('postgres_changes', { event: '*', schema: 'public', table: 'server_members', filter: `user_id=eq.${session.user.id}` }, ({ old: row }) => {
        setServers(prev => prev.filter(s => s.id !== row.server_id));
        setServerActuel(prev => prev?.id === row.server_id ? null : prev);
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'servers' }, ({ new: srv }) => {
        setServers(prev => prev.map(s => s.id === srv.id ? { ...s, ...srv } : s));
        setServerActuel(prev => prev?.id === srv.id ? { ...prev, ...srv } : prev);
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'servers' }, ({ old: srv }) => {
        setServers(prev => prev.filter(s => s.id !== srv.id));
        setServerActuel(prev => prev?.id === srv.id ? null : prev);
      })
      .subscribe();

    const canalProfils = supabase.channel('realtime-profiles')
      // 👇 AJOUT DE CETTE LIGNE (Pour les nouveaux inscrits) 👇
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'profiles' }, ({ new: profil }) => {
        setProfilsCache(prev => ({ ...prev, [profil.pseudo]: profil }));
      })
      // ────────────────────────────────────────────────────────
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'profiles' }, ({ new: profil }) => {
        setProfilsCache(prev => {
          let targetKey = profil.pseudo;
          Object.keys(prev).forEach(k => { if(prev[k].id === profil.id) targetKey = k; });
          return { ...prev, [targetKey]: profil };
        });
        if (profil.id === session.user.id) setMonProfil(profil);
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'profiles' }, ({ old: profil }) => {
        if (profil.pseudo) {
          setProfilsCache(prev => { const next = { ...prev }; delete next[profil.pseudo]; return next; });
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(radarGlobal);
      supabase.removeChannel(canalPresence);
      supabase.removeChannel(canalBroadcast);
      supabase.removeChannel(canalProfils);
      supabase.removeChannel(canalServers); // 👈 LA LIGNE MAGIQUE À AJOUTER
      canalTypingRef.current = null;
    };
  }, [session]); // monProfilRef utilisé dans le handler pour éviter les reconnexions

  useLayoutEffect(() => {
    if (forceScrollRef.current && conteneurMessagesRef.current) {
      if (premierNonLuId && ligneNonLuRef.current) {
        ligneNonLuRef.current.scrollIntoView({ behavior: 'auto', block: 'center' });
      } else {
        conteneurMessagesRef.current.scrollTop = conteneurMessagesRef.current.scrollHeight;
      }
      forceScrollRef.current = false;
    }
  }, [messages, premierNonLuId]);

  useEffect(() => {
    if (!session) return;
    const chargerMessages = async () => {
      const { data, error } = await supabase.from('messages')
        .select('*, reactions(*)')
        .eq('room', salonActuel)
        .order('created_at', { ascending: false })
        .limit(PAGE_SIZE);
      
      if (!error && data) {
        const chrono = data.reverse();
        setTousCharges(data.length < PAGE_SIZE);
        const dernierId = localStorage.getItem(`chat_dernier_lu_${salonActuel}`);
        let nonLuId = null;
        if (dernierId) {
          const idx = chrono.findIndex(m => m.id.toString() === dernierId);
          if (idx !== -1 && idx < chrono.length - 1) nonLuId = chrono[idx + 1].id;
        }
        
        setPremierNonLuId(nonLuId);
        forceScrollRef.current = true;
        setMessages(chrono);
      }
    };

    const chargerMessagesAnciens = async () => {
      if (tousChargesRef.current || chargementAnciensRef.current || messagesRef.current.length === 0) return;
      chargementAnciensRef.current = true;
      setChargementAnciens(true);
      const salon = salonActuelRef.current;
      const plusAncienDate = messagesRef.current[0].created_at;
      const { data, error } = await supabase.from('messages')
        .select('*, reactions(*)')
        .eq('room', salon)
        .lt('created_at', plusAncienDate)
        .order('created_at', { ascending: false })
        .limit(PAGE_SIZE);
      if (!error && data && data.length > 0) {
        const anciens = data.reverse();
        const estTous = data.length < PAGE_SIZE;
        tousChargesRef.current = estTous;
        setTousCharges(estTous);
        const c = conteneurMessagesRef.current;
        const scrollAvant = c ? c.scrollHeight - c.scrollTop : 0;
        isPrependingRef.current = true;
        setMessages(prev => [...anciens, ...prev]);
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            if (c) c.scrollTop = c.scrollHeight - scrollAvant;
            isPrependingRef.current = false;
            chargementAnciensRef.current = false;
            setChargementAnciens(false);
          });
        });
      } else {
        tousChargesRef.current = true;
        setTousCharges(true);
        chargementAnciensRef.current = false;
        setChargementAnciens(false);
      }
    };

    chargerMessagesAnciensRef.current = chargerMessagesAnciens;
    chargerMessages();

    const canalMessages = supabase.channel(`db-${salonActuel}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages', filter: `room=eq.${salonActuel}` }, ({ eventType, new: n, old: o }) => {
        if (eventType === 'INSERT') setMessages(prev => [...prev, { ...n, reactions: [] }]);
        else if (eventType === 'DELETE') setMessages(prev => prev.filter(m => m.id !== o.id));
        else if (eventType === 'UPDATE') setMessages(prev => prev.map(m => m.id === n.id ? { ...m, ...n } : m));
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'reactions' }, ({ new: r }) => {
        setMessages(prev => prev.map(m => {
          if (m.id !== r.message_id) return m;
          // On vérifie si on a déjà cette réaction (optimiste ou reçue d'un autre utilisateur)
          const dejaPresent = m.reactions?.find(rx => rx.username === r.username && rx.emoji === r.emoji);
          if (dejaPresent) {
            // On remplace simplement notre version "optimiste" par la version officielle (avec le bon ID)
            return { ...m, reactions: m.reactions.map(rx => rx === dejaPresent ? r : rx) };
          }
          return { ...m, reactions: [...(m.reactions || []), r] };
        }));
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'reactions' }, ({ old: r }) => {
        setMessages(prev => prev.map(m => ({ ...m, reactions: (m.reactions || []).filter(rx => rx.id !== r.id) })));
      })
      .subscribe();

    return () => { supabase.removeChannel(canalMessages); setAfficherNotif(false); };
  }, [session, salonActuel]);

  const chargerMessagesAnciens = () => chargerMessagesAnciensRef.current?.();

  const sInscrire = async (e) => {
    e.preventDefault();
    setAuthError("");
    
    if (!email || !password) return setAuthError("Veuillez remplir tous les champs.");
    if (password.length < 6) return setAuthError("Le mot de passe doit faire 6 car. min.");

    // Le vrai verrou est maintenant dans Supabase (Trigger SQL), 
    // mais on garde ceci pour un message d'erreur instantané sans requête Auth.
    const { data: banned } = await supabase
      .from('banned_emails')
      .select('email')
      .eq('email', email.toLowerCase())
      .maybeSingle();

    if (banned) return setAuthError("Cette adresse email est bannie définitivement.");

    const { error } = await supabase.auth.signUp({ email: email.toLowerCase().trim(), password });
    if (error) {
      // Le trigger SQL renvoie le message dans error.message
      if (error.message.includes('bannie')) setAuthError("Cette adresse email est bannie définitivement.");
      else setAuthError(error.message);
    }
    else {
      setVueActive('chat'); // 👈 FORCE LA VUE
      localStorage.setItem('chat_vue_active', 'chat'); // 👈 SAUVEGARDE
    }
  };
  const seConnecter = async (e) => { e.preventDefault(); setAuthError(""); if (!email || !password) return setAuthError("Veuillez remplir tous les champs."); const { error } = await supabase.auth.signInWithPassword({ email, password }); if (error) { if (error.message.includes("Invalid login")) setAuthError("Email/Mot de passe incorrect."); else setAuthError(error.message); }  else { setVueActive('chat'); localStorage.setItem('chat_vue_active', 'chat');}};
  const seDeconnecter = async () => { 
      await supabase.removeAllChannels(); 
      setUtilisateursEnLigne([]); 
      setSalonsPrives([]); 
      setNotifications({}); 
      // 🧹 NETTOYAGE COMPLET
      localStorage.clear(); 
      await supabase.auth.signOut(); 
      window.location.reload(); // Optionnel : recharge pour repartir à zéro
    };
    const toggleMode = () => { setIsLogin(!isLogin); setAuthError(""); setPassword(""); };

  const lancerRecherche = async (query) => {
    if (!query.trim()) { setRechercheResultats([]); return; }
    setRechercheEnCours(true);
    const { data } = await supabase.from('messages').select('id, content, username, room, created_at').ilike('content', `%${query}%`).order('created_at', { ascending: false }).limit(50);
    setRechercheResultats(data || []);
    setRechercheEnCours(false);
  };

  const allerAuMessage = (msgId, room) => {
    if (room !== salonActuel) { changerSalon(room); return; }
    const el = messagesRefsMap.current[msgId];
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('ring-2', 'ring-primary', 'rounded-xl');
      setTimeout(() => el.classList.remove('ring-2', 'ring-primary', 'rounded-xl'), 2000);
    }
    setRechercheOuverte(false);
  };

  const surlignerTexte = (texte, query) => {
    if (!query.trim() || !texte) return texte;
    const idx = texte.toLowerCase().indexOf(query.toLowerCase());
    if (idx === -1) return texte;
    return [texte.slice(0, idx), <mark key="m" className="bg-primary/30 text-base-content rounded px-0.5 font-bold">{texte.slice(idx, idx + query.length)}</mark>, texte.slice(idx + query.length)];
  };

  const ouvrirGif = async () => {
    setGifOuvert(v => !v);
    if (gifTendances.length === 0 && GIPHY_KEY) {
      setGifChargement(true);
      try {
        const res = await fetch(`https://api.giphy.com/v1/gifs/trending?api_key=${GIPHY_KEY}&limit=24&rating=g`);
        const json = await res.json();
        setGifTendances(json.data || []);
      } catch (err) {
        console.error("Erreur Giphy Tendances:", err);
      } finally {
        setGifChargement(false);
      }
    }
  };

  const rechercherGifs = async (query) => {
    setGifQuery(query);
    if (!query.trim()) { setGifResultats([]); return; }
    if (!GIPHY_KEY) return;

    setGifChargement(true);
    try {
      const res = await fetch(`https://api.giphy.com/v1/gifs/search?api_key=${GIPHY_KEY}&q=${encodeURIComponent(query)}&limit=24&rating=g`);
      const json = await res.json();
      setGifResultats(json.data || []);
    } catch (err) {
      console.error("Erreur Giphy Recherche:", err);
    } finally {
      setGifChargement(false);
    }
  };

  const envoyerGif = async (gif) => {
    const url = gif.images.original.url;
    const pseudo = session.user.email.split('@')[0];
    const pseudoAffiche = monProfil?.pseudo || pseudo;
    setGifOuvert(false);
    await supabase.from('messages').insert([{
      content: '',
      username: pseudoAffiche,
      room: salonActuel,
      image_url: url,
    }]);
    scrollerVersLeBas();
  };

  const insererEmoji = (emoji) => {
    setNouveauMessage(prev => prev + emoji);
    setTimeout(() => {
      const input = inputMessageRef.current;
      if (input) {
        input.focus();
        const len = input.value.length;
        input.setSelectionRange(len, len);
      }
    }, 0);
  };

  const gererFrappe = (e) => {
    const val = e.target.value;
    setNouveauMessage(val);

    // --- LOGIQUE TYPING (INDICATEUR D'ÉCRITURE) ---
    if (!session) return;
    const pseudoAffiche = monProfil?.pseudo || session.user.email.split('@')[0];
    if (!typingTimeoutRef.current) {
      canalTypingRef.current?.send({
        type: 'broadcast',
        event: 'typing',
        payload: { pseudo: pseudoAffiche, salon: salonActuelRef.current, typing: true }
      });
    }
    clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      canalTypingRef.current?.send({
        type: 'broadcast',
        event: 'typing',
        payload: { pseudo: pseudoAffiche, salon: salonActuelRef.current, typing: false }
      });
      typingTimeoutRef.current = null;
    }, 2000);

    // --- NOUVELLE LOGIQUE MENTIONS (@) ---
    const cursorPosition = e.target.selectionStart;
    const textBeforeCursor = val.slice(0, cursorPosition);
    const words = textBeforeCursor.split(/\s/);
    const lastWord = words[words.length - 1];

    if (lastWord.startsWith('@')) {
      setMentionQuery(lastWord.slice(1).toLowerCase());
      setMentionIndex(0);
    } else {
      setMentionQuery(null);
    }
  };

  const dernierEnvoiRef = useRef(0);
  const envoyerMessage = async () => {
    if (!nouveauMessage.trim()) return;

    // 1. On récupère les pseudos de tes vrais amis
    const pseudosAmis = amis.map(f => {
      const idAmi = f.requester_id === session.user.id ? f.receiver_id : f.requester_id;
      return Object.values(profilsCache).find(p => p.id === idAmi)?.pseudo;
    }).filter(Boolean);

    // 2. On extrait ce que tu as tapé
    const regexMention = /@(\w+)/g;
    const motsApresArobase = [...nouveauMessage.matchAll(regexMention)].map(m => m[1]);

    // 3. On ne garde QUE les mentions qui correspondent à un ami réel
    const mentionsValides = motsApresArobase.filter(pseudo => pseudosAmis.includes(pseudo));

    const pseudoAffiche = monProfil?.pseudo || session.user.email.split('@')[0];
    const texte = nouveauMessage;
    const reponse = reponseA ? reponseA.id : null;
    
    setNouveauMessage(""); 
    setReponseA(null);
    setMentionQuery(null); // On ferme le menu au cas où
    clearTimeout(typingTimeoutRef.current);
    canalTypingRef.current?.send({ type: 'broadcast', event: 'typing', payload: { pseudo: pseudoAffiche, salon: salonActuelRef.current, typing: false } });
    scrollerVersLeBas();
    
    await supabase.from('messages').insert([{ 
      content: texte, 
      username: pseudoAffiche, 
      room: salonActuel, 
      reply_to_id: reponse,
      mentions: mentionsValides // 👈 On envoie uniquement les vrais pseudos ici
    }]);
  };

  
  const envoyerImage = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setIsUploading(true);
    const pseudoAffiche = monProfil?.pseudo || session.user.email.split('@')[0];
    const ext = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${ext}`;
    const salonPropre = salonActuel.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9_-]/g, "").toLowerCase();
    const { error: uploadError } = await supabase.storage.from('chat-images').upload(`${salonPropre}/${fileName}`, file);
    if (uploadError) { ajouterToast("Erreur upload : " + uploadError.message, "error"); setIsUploading(false); return; }
    const { data: { publicUrl } } = supabase.storage.from('chat-images').getPublicUrl(`${salonPropre}/${fileName}`);
    await supabase.from('messages').insert([{ content: "", username: pseudoAffiche, room: salonActuel, image_url: publicUrl }]);
    setIsUploading(false); scrollerVersLeBas();
  };

  const confirmerEnvoiFichier = async () => {
    // Si preview n'est plus là, annuler
    if (!fichierPreview) return;
    setIsUploading(true);
    const { file, type } = fichierPreview;
    
    const pseudoAffiche = monProfil?.pseudo || session.user.email.split('@')[0];
    const ext = file.name.split('.').pop().toLowerCase();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${ext}`;
    const salonPropre = salonActuel.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9_-]/g, "").toLowerCase();

    const bucket = type.startsWith('image/') ? 'chat-images' : 'chat-files';
    const { error } = await supabase.storage.from(bucket).upload(`${salonPropre}/${fileName}`, file);
    if (error) {
      ajouterToast('Erreur upload : ' + error.message, 'error');
      setIsUploading(false);
      return;
    }
    const { data: { publicUrl } } = supabase.storage.from(bucket).getPublicUrl(`${salonPropre}/${fileName}`);
    const { error: insertError } = await supabase.from('messages').insert([{
      content: '',
      username: pseudoAffiche,
      room: salonActuel,
      image_url: publicUrl,
      file_name: file.name,
      file_type: type,
    }]);
    if (insertError) ajouterToast('Erreur envoi : ' + insertError.message, 'error');
    if (fichierPreview.url) {
      URL.revokeObjectURL(fichierPreview.url);
    }
    setIsUploading(false);
    setFichierPreview(null);
    scrollerVersLeBas();
  };

  const envoyerFichier = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    event.target.value = '';

    const MAX = 50 * 1024 * 1024;
    if (file.size > MAX) { ajouterToast('Fichier trop lourd (max 50 Mo)', 'error'); return; }

    const url = URL.createObjectURL(file);
    setFichierPreview({ file, url, type: file.type });
  };

  const supprimerMessage = async (id) => {
    const el = messagesRefsMap.current[id];
    if (el) {
      el.style.transition = 'opacity 0.35s ease, transform 0.35s ease';
      el.style.opacity = '0';
      el.style.transform = 'scale(0.97)';
    }
    setTimeout(async () => {
      const { error } = await supabase.from('messages').delete().eq('id', id);
      if (error) {
        if (el) { el.style.opacity = '1'; el.style.transform = 'scale(1)'; }
        ajouterToast("Erreur lors de la suppression.", 'error');
      }
    }, 300);
  };
  const sauvegarderModification = async (id) => { 
    if (!texteEdition.trim()) return; 
    const { error } = await supabase
      .from('messages')
      .update({ 
        content: texteEdition,
        updated_at: new Date().toISOString() // 👈 Pareil ici !
      })
      .eq('id', id); 
      
    if (!error) { 
      setMessageEnEdition(null); 
      setTexteEdition(""); 
    } else {
      ajouterToast(`Erreur modification : ${error.message}`, "error");
    }
  };

  const toggleReaction = async (messageId, emoji) => {
    const pseudoAffiche = monProfil?.pseudo || session.user.email.split("@")[0];
    const message = messages.find(m => m.id === messageId);
    if (!message) return;
    
    const existing = message.reactions?.find(r => r.username === pseudoAffiche && r.emoji === emoji);
    
    if (existing) {
      // Optimistic Delete
      setMessages(prev => prev.map(m => m.id === messageId ? { ...m, reactions: m.reactions.filter(r => r.id !== existing.id) } : m));
      await supabase.from("reactions").delete().eq("id", existing.id);
    } else {
      // Optimistic Add
      const fakeReaction = { id: Date.now(), message_id: messageId, username: pseudoAffiche, emoji };
      setMessages(prev => prev.map(m => m.id === messageId ? { ...m, reactions: [...(m.reactions || []), fakeReaction] } : m));
      await supabase.from("reactions").insert([{ message_id: messageId, username: pseudoAffiche, emoji }]);
    }
  };

  const getAvatarUrlForDisplay = (username) => {
    if (!username || username === '[supprimé]') 
      return `https://ui-avatars.com/api/?name=?&background=6b7280&color=fff&rounded=true&size=32&bold=true`;
    let p = profilsCache[username];
    if(!p) {
        Object.keys(profilsCache).forEach(k => { if(profilsCache[k].pseudo === username) p = profilsCache[k]; });
    }
    if (p && p.avatar_url) return p.avatar_url;
    const initials = username.split('.').map(part => part[0].toUpperCase()).join('');
    return `https://ui-avatars.com/api/?name=${initials}&background=random&rounded=true&size=32&bold=true`;
  };

  // 👇 LOGIQUE DES AMIS 👇
  // ── LOGIQUE DES AMIS & TEMPS RÉEL ──
  const chargerAmis = async () => {
    if (!session?.user) return;
    const { data, error } = await supabase.from('friendships').select('*')
      .or(`requester_id.eq.${session.user.id},receiver_id.eq.${session.user.id}`);
    
    if (data) {
      const amiIds = data.map(f => f.requester_id === session.user.id ? f.receiver_id : f.requester_id);
      if (amiIds.length > 0) {
        const { data: profilsAmis } = await supabase.from('profiles').select('*').in('id', amiIds);
        if (profilsAmis) {
          setProfilsCache(prev => {
            const maj = { ...prev };
            profilsAmis.forEach(p => maj[p.pseudo] = p);
            return maj;
          });
        }
      }
      setAmis(data.filter(f => f.status === 'accepted'));
      
      // On filtre pour ne garder QUE les demandes qu'on a reçues
      const enAttente = data.filter(f => f.status === 'pending' && f.receiver_id === session.user.id);
      
      setDemandesAmis(enAttente); // 👈 Maintenant, la liste n'affiche que les reçues !
      setDemandesEnAttente(enAttente.length);
    }
    setFriendsLoaded(true);
  };

  useEffect(() => {
    if (!session) return;
    chargerAmis();

    const canalAmis = supabase.channel('realtime-friendships')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'friendships' }, () => {
        chargerAmis(); // Recharge TOUT en direct (Ajout, Acceptation, Suppression)
      })
      .subscribe();

    return () => supabase.removeChannel(canalAmis);
  }, [session]);

  const getProfilAmi = (f) => {
    const amiId = f.requester_id === session?.user?.id ? f.receiver_id : f.requester_id;
    return Object.values(profilsCache).find(p => p.id === amiId) || { id: amiId, pseudo: 'Utilisateur inconnu' };
  };

  const envoyerDemandeAmi = async (e) => {
    e.preventDefault();
    if (!rechercheAmi.trim()) return;
    setAjoutAmiLoading(true);
    const { data: target } = await supabase.from('profiles').select('*').ilike('pseudo', rechercheAmi.trim()).single();
    if (!target) { ajouterToast("Utilisateur introuvable", "error"); setAjoutAmiLoading(false); return; }
    if (target.id === session.user.id) { ajouterToast("C'est vous !", "error"); setAjoutAmiLoading(false); return; }

    // 👇 AJOUT : On force le profil dans le cache pour l'affichage immédiat 👇
    setProfilsCache(prev => ({ ...prev, [target.pseudo]: target }));

    const exist = [...amis, ...demandesAmis].find(f => f.requester_id === target.id || f.receiver_id === target.id);
    if (exist) { ajouterToast("Demande déjà existante ou déjà amis.", "error"); setAjoutAmiLoading(false); return; }

    const { error } = await supabase.from('friendships').insert({ requester_id: session.user.id, receiver_id: target.id, status: 'pending' });
    if (error) ajouterToast("Erreur: " + error.message, "error");
    else { ajouterToast("Demande envoyée à " + target.pseudo); setRechercheAmi(''); }
    setAjoutAmiLoading(false);
  };

  const repondreDemandeAmi = async (id, accepter) => {
    // Optimistic UI : On cache instantanément la demande de l'écran
    setDemandesAmis(prev => prev.filter(f => f.id !== id));
    
    if (accepter) {
      await supabase.from('friendships').update({ status: 'accepted' }).eq('id', id);
      ajouterToast("Nouvel ami ajouté !");
    } else {
      await supabase.from('friendships').delete().eq('id', id);
    }
  };

  const supprimerAmi = async (amitieId) => {
    // On supprime directement la ligne grâce à son ID unique
    const { error } = await supabase
      .from('friendships')
      .delete()
      .eq('id', amitieId);

    if (error) {
      ajouterToast("Erreur lors de la suppression : " + error.message, "error");
    } else {
      ajouterToast("Ami retiré", "success");
      // La magie du "live" (le canalAmis) va s'occuper de rafraîchir l'écran des deux côtés instantanément !
    }
  };
  // 👆 FIN LOGIQUE DES AMIS 👆
  // 🚀 L'ÉCRAN DE CHARGEMENT GLOBAL 🚀
  // 🚀 L'ÉCRAN DE CHARGEMENT GLOBAL 🚀
  if (!authLoaded || (session && !dataLoaded)) {
    return (
      <div className="flex h-screen w-full bg-base-300 items-center justify-center flex-col gap-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03]"></div>
        
        <div className="relative z-10 flex flex-col items-center">
          
          {/* 👇 Le VRAI spinner Atom avec Lucide React 👇 */}
          <div className="relative flex items-center justify-center mb-4">
            {/* Le noyau qui pulse */}
            <div className="w-3 h-3 bg-primary rounded-full animate-ping absolute"></div>
            <div className="w-3 h-3 bg-primary rounded-full absolute"></div>
            
            {/* Les orbites de l'atome qui tournent doucement */}
            <Atom size={72} className="text-primary opacity-80 animate-[spin_4s_linear_infinite]" strokeWidth={1} />
          </div>
          
          <span className="text-sm font-black text-base-content/60 uppercase tracking-[0.3em] mt-2 animate-pulse">
            Chargement...
          </span>
        </div>
      </div>
    );
  }
  
  if (!session) {
    return (
      <LandingPage 
        isTransitioningAuth={isTransitioningAuth}
        showAuthForm={showAuthForm}
        basculerVersAccueil={basculerVersAccueil}
        basculerVersFormulaire={basculerVersFormulaire}
        isLogin={isLogin}
        authError={authError}
        email={email}
        setEmail={setEmail}
        password={password}
        setPassword={setPassword}
        seConnecter={seConnecter}
        sInscrire={sInscrire}
      />
    );
  }

  

  const monPseudoTech = session.user.email.split('@')[0];
  const monPseudoAffiche = monProfil?.pseudo || monPseudoTech;
  const totalNotifsDMs = Object.entries(notifications)
    .filter(([room]) => room.startsWith('dm_'))
    .reduce((acc, [, count]) => acc + count, 0);

  return (
    <AppProvider 
      session={session} 
      monProfil={monProfil} 
      ajouterToast={ajouterToast}
      // 👇 ON INJECTE LE RADAR ICI 👇
      utilisateursEnLigne={utilisateursEnLigne}
      profilsCache={profilsCache}
      getStatutEffectif={getStatutEffectif}
    >
    <div className="flex h-screen bg-base-200 relative overflow-hidden">
      <MobileOverlay />
      {estHorsLigne && (
        <div className="fixed top-0 left-0 right-0 z-[500] bg-error text-error-content text-center text-sm font-bold py-2 flex items-center justify-center gap-2">
          ⚡ Connexion perdue — les messages ne seront pas envoyés
        </div>
      )}
      {/* ── TOASTS DÉPLACÉS (Optionnel car maintenant dans UIContext) ── */}
        <div className="fixed bottom-5 right-5 z-[9999] flex flex-col gap-2 items-end pointer-events-none">
          {toasts.map(t => (
            <div key={t.id} className={`pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-xl shadow-xl text-sm font-medium border backdrop-blur-sm
              animate-[toastIn_0.25s_cubic-bezier(0.34,1.56,0.64,1)_forwards]
              ${t.type === 'error' ? 'bg-error/90 text-error-content border-error/30' : 'bg-base-100 text-base-content border-base-300'}`}>
              <span>{t.type === 'error' ? '✕' : '✓'}</span>
              <span>{t.message}</span>
            </div>
          ))}
        </div>

      {/* ── MODALE DE CONFIRMATION ───────────────────────────── */}
      {modalConfirm && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center">
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setModalConfirm(null)} />
          <div className="relative pointer-events-auto bg-base-100 rounded-2xl shadow-2xl border border-base-200 w-full max-w-xs mx-4 p-5 z-10 animate-[modalIn_0.18s_cubic-bezier(0.34,1.2,0.64,1)_forwards]">
            <p className="text-sm text-base-content/80 mb-4 leading-relaxed">{modalConfirm.message}</p>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setModalConfirm(null)} className="btn btn-ghost btn-sm">Annuler</button>
              <button onClick={() => { modalConfirm.onConfirm(); setModalConfirm(null); }}
                className={`btn btn-sm ${modalConfirm.danger ? 'btn-error' : 'btn-primary'}`}>
                Confirmer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── MENU CLIC DROIT & POPOVER (Global UI) ───────────── */}
      <style>{`
        @keyframes toastIn { from{opacity:0;transform:translateX(16px) scale(0.95)} to{opacity:1;transform:translateX(0) scale(1)} }
        @keyframes modalIn { from{opacity:0;transform:scale(0.95) translateY(8px)} to{opacity:1;transform:scale(1) translateY(0)} }
        @keyframes menuAppear { from{opacity:0;transform:scale(0.92) translateY(-6px)} to{opacity:1;transform:scale(1) translateY(0)} }
        @keyframes popoverAppear { from{opacity:0;transform:scale(0.94) translateY(-4px)} to{opacity:1;transform:scale(1) translateY(0)} }
        .popover-appear { animation: popoverAppear 0.15s cubic-bezier(0.34,1.4,0.64,1) forwards; }
        @keyframes menuDisappear { from{opacity:1;transform:scale(1) translateY(0)} to{opacity:0;transform:scale(0.92) translateY(-6px)} }
        .menu-contextuel-enter{animation:menuAppear 0.15s cubic-bezier(0.34,1.56,0.64,1) forwards;transform-origin:top left}
        .menu-contextuel-exit{animation:menuDisappear 0.12s ease-in forwards;transform-origin:top left}
        @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        .animate-fade-in{animation:fadeIn 0.2s ease forwards}
        @keyframes emojiPop{0%{opacity:0;transform:scale(0.5) translateY(4px)}70%{transform:scale(1.15) translateY(-2px)}100%{opacity:1;transform:scale(1) translateY(0)}}
        .emoji-btn{animation:emojiPop 0.2s ease forwards}
        @keyframes formatPopIn { 0% {opacity:0; transform:scale(0.9) translateY(4px)} 100% {opacity:1; transform:scale(1) translateY(0)} }
        @keyframes formatPopOut { 0% {opacity:1; transform:scale(1) translateY(0)} 100% {opacity:0; transform:scale(0.9) translateY(4px)} }
        .format-enter { animation: formatPopIn 0.15s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; transform-origin: bottom left; }
        .format-exit { animation: formatPopOut 0.15s ease-in forwards; transform-origin: bottom left; }
        @keyframes reactionAppear{0%{opacity:0;transform:scale(0.6)}60%{transform:scale(1.18)}100%{opacity:1;transform:scale(1)}}
        .reaction-badge{animation:reactionAppear 0.2s cubic-bezier(0.34,1.56,0.64,1) forwards;transform-origin:center}
        .reaction-tooltip{visibility:hidden;opacity:0;transform:translateY(4px) scale(0.96);transition:opacity 0.15s ease,transform 0.15s ease,visibility 0s linear 0.15s;pointer-events:none}
        .reaction-wrapper:hover .reaction-tooltip{visibility:visible;opacity:1;transform:translateY(0) scale(1);transition:opacity 0.15s ease,transform 0.15s ease,visibility 0s linear 0s}
        @keyframes atom-spinner-animation-1 {
          0% { transform: rotateZ(120deg) rotateX(66deg) rotateZ(0deg); }
          100% { transform: rotateZ(120deg) rotateX(66deg) rotateZ(360deg); }
        }
        @keyframes atom-spinner-animation-2 {
          0% { transform: rotateZ(240deg) rotateX(66deg) rotateZ(0deg); }
          100% { transform: rotateZ(240deg) rotateX(66deg) rotateZ(360deg); }
        }
        @keyframes atom-spinner-animation-3 {
          0% { transform: rotateZ(360deg) rotateX(66deg) rotateZ(0deg); }
          100% { transform: rotateZ(360deg) rotateX(66deg) rotateZ(360deg); }
        }

        .atom-line {
          position: absolute;
          width: 100%;
          height: 100%;
          border-radius: 50%;
          border-left-width: 3px;
          border-left-color: #5865F2; /* Ta couleur primary */
          border-top-width: 0px;
        }
          @keyframes skeleton-glow {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }

        .skeleton-box {
          background: linear-gradient(90deg, oklch(var(--b2)) 25%, oklch(var(--b3)) 50%, oklch(var(--b2)) 75%);
          background-size: 200% 100%;
          animation: skeleton-glow 1.5s infinite linear;
        }
      `}</style>

      {/* ── POPOVER PROFIL EXTERNALISÉ ── */}
      <ProfilPopover 
        profilPopover={profilPopover}
        setProfilPopover={setProfilPopover}
        getAvatarUrlForDisplay={getAvatarUrlForDisplay}
        getStatutEffectif={getStatutEffectif}
        demarrerDM={demarrerDM}
        session={session}
        amis={amis}
        demandesAmis={demandesAmis}
        ajouterToast={ajouterToast}
      />

      {menuContextuel && (
        <div className={`fixed z-[70] bg-base-100 rounded-xl shadow-2xl border border-base-200 py-2 w-52 text-sm overflow-hidden ${menuFermeture ? 'menu-contextuel-exit' : 'menu-contextuel-enter'}`}
          style={{ top: menuContextuel.y, left: menuContextuel.x }}>
          <div className="px-3 pb-2 mb-1 border-b border-base-200 font-bold text-xs text-gray-400 truncate uppercase tracking-wider">
            {menuContextuel.message.username}
          </div>
          <div className="flex items-center justify-around px-3 py-2 mb-1 border-b border-base-200">
            {emojisDispos.map((emoji, i) => {
              const live = messages.find(m => m.id === menuContextuel.message.id);
              const dejaReagi = live?.reactions?.some(r => r.username === monPseudoAffiche && r.emoji === emoji);
              return (
                <button key={emoji} className={`emoji-btn text-xl transition-all duration-100 hover:scale-125 active:scale-95 rounded-lg p-1 ${dejaReagi ? 'bg-primary/15 ring-1 ring-primary/40' : 'hover:bg-base-200'}`}
                  style={{ animationDelay: `${i * 30}ms`, opacity: 0 }}
                  onClick={() => { toggleReaction(menuContextuel.message.id, emoji); fermerMenuContextuel(); }}>
                  {emoji}
                </button>
              );
            })}
          </div>
          <ul className="menu p-0">
            <li><a onClick={() => { setReponseA(menuContextuel.message); fermerMenuContextuel(); }}><Reply size={16} /> Répondre</a></li>
            {menuContextuel.message.username === monPseudoAffiche && (<>
              <li><a onClick={() => { setMessageEnEdition(menuContextuel.message.id); setTexteEdition(menuContextuel.message.content); fermerMenuContextuel(); }}><Pencil size={16} /> Modifier</a></li>
              <li><a className="text-error hover:bg-error/10 hover:text-error" onClick={() => { supprimerMessage(menuContextuel.message.id); fermerMenuContextuel(); }}><Trash size={16} /> Supprimer</a></li>
            </>)}
          </ul>
        </div>
      )}
      {/* ────────────────────────────────────────────────── */}
      <ServerSidebar
        servers={servers}
        setServers={setServers} /* 👈 LA SOLUTION EST ICI : Cela permet de sauvegarder l'ordre du Drag & Drop */
        serverActuel={serverActuel} 
        isHome={!serverActuel && vueActive !== 'explorer'}
        notifications={notifications}
        groups={groups}
        setGroups={setGroups}
        memberMeta={memberMeta}
        setMemberMeta={setMemberMeta}
        onSelectHome={() => { 
          setServerActuel(null); 
          setVueActive('chat');
          localStorage.removeItem('chat_server_id'); 
          localStorage.removeItem('chat_channel_id'); 
          // On ne remove PAS chat_salon_actuel ici !
        }}
        onSelectServer={(srv, ch) => { 
          setServerActuel(srv); 
          setServerChannel(ch); 
          setVueActive('chat');
          localStorage.setItem('chat_server_id', srv.id);
          if (ch) {
            localStorage.setItem('chat_channel_id', ch.id);
          } else {
            localStorage.removeItem('chat_channel_id'); // 🧹 On vide la mémoire si on va sur un serveur sans salon ciblé
          }
        }}
        onSelectExplorer={() => { 
          setServerActuel(null); 
          setVueActive('explorer'); 
          chargerPublicServers(); 
        }}
        onLeaveServer={(serverId) => { /* 👈 Ajouté pour que le bouton "Quitter" du menu clic droit fonctionne */
          setServers(prev => prev.filter(s => s.id !== serverId));
          if (serverActuel?.id === serverId) { setServerActuel(null); setVueActive('chat'); }
        }}
        vueActive={vueActive}
        notifsDMs={totalNotifsDMs}
        demandesEnAttente={demandesEnAttente} // 👈 NOUVELLE PROP
      />
      {serverActuel ? (
        <ServerView
          key={serverActuel.id}
          notifications={notifications}
          server={serverActuel} 
          initialChannel={serverChannel}
          profilsCache={profilsCache} // 👈 LA LIGNE SALVATRICE EST ICI
          getStatutEffectif={getStatutEffectif} // 👈 AJOUTE CETTE LIGNE ICI
          onLeave={() => { setServers(prev => prev.filter(s => s.id !== serverActuel.id)); setServerActuel(null); }}
          onUserClick={gererClicProfil}
          getAvatarUrl={getAvatarUrlForDisplay}
          onChannelSelect={(ch) => { 
            setServerChannel(ch); 
            localStorage.setItem('chat_channel_id', ch.id); 
            setNotifications(prev => { 
              const n = {...prev}; 
              delete n[`server-${serverActuel.id}-${ch.id}`]; 
              return n; 
            }); 
          }}
          onOpenParametres={() => { 
            setServerPrecedent(serverActuel);
            setServerActuel(null); 
            ouvrirParametres(); 
          }}
          onLogout={() => demanderConfirmation("Se déconnecter ?", seDeconnecter, false)}
        />
      ) : (
      <div className="flex-1 flex overflow-hidden relative">

      

      {/* ── SIDEBAR DMs EXTERNALISÉE ── */}
        <SidebarDMs
          salonActuel={salonActuel}
          changerSalon={changerSalon}
          vueActive={vueActive}
          demandesAmis={demandesAmis}
          salonsPrives={salonsPrives}
          profilsCache={profilsCache}
          utilisateursEnLigne={utilisateursEnLigne}
          getStatutEffectif={getStatutEffectif}
          getAvatarUrlForDisplay={getAvatarUrlForDisplay}
          notifications={notifications}
          supprimerSalonDM={supprimerSalonDM}
          ouvrirParametres={ouvrirParametres}
          demanderConfirmation={demanderConfirmation}
          seDeconnecter={seDeconnecter}
        />
          
      <div className="flex-1 flex flex-col h-screen relative bg-base-100">
        
        {/* VUE PARAMÈTRES */}
        {/* VUE PARAMÈTRES */}
        {vueActive === 'parametres' ? (
          <VueParametres 
            session={session}
            monProfil={monProfil}
            monPseudoAffiche={monPseudoAffiche}
            setVueActive={setVueActive}
            ongletParametres={ongletParametres}
            setOngletParametres={setOngletParametres}
            editPseudo={editPseudo}
            setEditPseudo={setEditPseudo}
            editBio={editBio}
            setEditBio={setEditBio}
            editStatut={editStatut}
            setEditStatut={setEditStatut}
            editAvatarUrl={editAvatarUrl}
            editPassword={editPassword}
            setEditPassword={setEditPassword}
            uploadAvatarEnCours={uploadAvatarEnCours}
            sauvegardeEnCours={sauvegardeEnCours}
            avatarInputRef={avatarInputRef}
            handleAvatarUpload={handleAvatarUpload}
            sauvegarderParametres={sauvegarderParametres}
            changerMotDePasse={changerMotDePasse}
            supprimerMonCompte={supprimerMonCompte}
            getAvatarUrlForDisplay={getAvatarUrlForDisplay}
            serverPrecedent={serverPrecedent}
            setServerActuel={setServerActuel}
            setServerPrecedent={setServerPrecedent}
            themeActuel={themeActuel}
            setThemeActuel={setThemeActuel}
            demanderConfirmation={demanderConfirmation}
          />
        ) : vueActive === 'explorer' ? (
          <VueExplorateur 
            rechercheExplorer={rechercheExplorer}
            setRechercheExplorer={setRechercheExplorer}
            explorerLoading={explorerLoading}
            publicServers={publicServers}
            servers={servers}
            rejoindreServeurPublic={rejoindreServeurPublic}
          />
        ) : salonActuel ? (
          /* VUE CHAT DMs CLASSIQUE */
          <>
            <div className="bg-base-100 p-4 border-b border-base-200 flex items-center gap-2 font-bold shadow-sm z-10">
              
              {/* 👇 LE NOUVEAU BOUTON BURGER EST ICI 👇 */}
              <BurgerButton />

              {salonActuel.startsWith('dm_') ? <MessageCircle size={20} className="text-primary"/> : <Hash size={20} className="text-gray-400"/>}
              <span className="flex-1">{getNomSalonAffichage()}</span>
              
              <button onClick={() => { setRechercheOuverte(v => !v); setRechercheQuery(''); setRechercheResultats([]); }}
                className={`btn btn-ghost btn-sm btn-circle transition-colors ${rechercheOuverte ? 'text-primary bg-primary/10' : 'text-gray-400 hover:text-primary'}`}>
                <Search size={18} />
              </button>
            </div>

            {rechercheOuverte && (
              <div className="bg-base-100 border-b border-base-200 shadow-md z-10">
                <div className="p-3 flex gap-2 items-center">
                  <div className="relative flex-1">
                    <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                    <input ref={rechercheRef} autoFocus type="text" placeholder="Rechercher dans tous les messages…"
                      className="input input-bordered input-sm w-full pl-9" value={rechercheQuery}
                      onChange={e => { setRechercheQuery(e.target.value); lancerRecherche(e.target.value); }}
                      onKeyDown={e => e.key === 'Escape' && setRechercheOuverte(false)} />
                    {rechercheEnCours && <Loader2 size={14} className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin text-gray-400" />}
                  </div>
                  <button onClick={() => setRechercheOuverte(false)} className="btn btn-ghost btn-sm btn-circle text-gray-400"><X size={16}/></button>
                </div>
                {rechercheResultats.length > 0 && (
                  <div className="max-h-72 overflow-y-auto border-t border-base-200 divide-y divide-base-200">
                    {rechercheResultats.map(msg => (
                      <button key={msg.id} onClick={() => allerAuMessage(msg.id, msg.room)} className="w-full text-left px-4 py-2.5 hover:bg-base-200 transition-colors flex flex-col gap-0.5">
                        <div className="flex items-center gap-2">
                          <img src={getAvatarUrlForDisplay(msg.username)} className="w-5 h-5 rounded-full flex-shrink-0 object-cover" />
                          <span className="font-bold text-xs text-base-content">{msg.username}</span>
                          <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded-full ml-auto flex-shrink-0 ${msg.room === salonActuel ? 'bg-primary/15 text-primary' : 'bg-base-300 text-gray-500'}`}>
                            {msg.room.startsWith('dm_') ? '@ DM' : `# ${msg.room}`}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 truncate pl-7">{surlignerTexte(msg.content, rechercheQuery)}</p>
                      </button>
                    ))}
                  </div>
                )}
                {rechercheQuery.trim() && !rechercheEnCours && rechercheResultats.length === 0 && (
                  <div className="px-4 py-3 text-xs text-gray-400 text-center border-t border-base-200">Aucun résultat pour « {rechercheQuery} »</div>
                )}
              </div>
            )}

            {afficherNotif && (
              <button onClick={() => { scrollerVersLeBas(); setPremierNonLuId(null); if (messages.length > 0) localStorage.setItem(`chat_dernier_lu_${salonActuel}`, messages[messages.length - 1].id.toString()); }}
                className="absolute top-14 left-0 w-full z-20 bg-primary/95 backdrop-blur text-primary-content font-bold text-sm py-3 shadow-md flex justify-center items-center gap-3 hover:bg-primary transition-colors cursor-pointer border-b border-primary-content/20">
                <span>Nouveaux messages en bas</span>
                <div className="bg-primary-content/20 rounded-full p-1 animate-bounce"><ArrowDown size={16} /></div>
              </button>
            )}

            <div className="flex-1 p-4 overflow-y-auto bg-base-100 flex flex-col gap-4 relative" ref={conteneurMessagesRef} onScroll={gererScroll}>
              {chargementAnciens && <div className="flex justify-center py-2"><Loader2 size={18} className="animate-spin text-gray-400" /></div>}
              {tousCharges && !chargementAnciens && messages.length > 0 && (
                <div className="flex items-center gap-3 my-2 px-2">
                  <div className="flex-1 h-px bg-base-300"></div>
                  <span className="text-[11px] text-gray-400 whitespace-nowrap">Début de l'historique</span>
                  <div className="flex-1 h-px bg-base-300"></div>
                </div>
              )}

              {messages.map((msg, index) => {
                // On prépare uniquement les données brutes nécessaires
                const messagePrecedent = index > 0 ? messages[index - 1] : null;
                const messageParent = msg.reply_to_id ? messages.find(m => m.id === msg.reply_to_id) : null;
                const estPremierNonLu = msg.id === premierNonLuId;

                let auteurTech = msg.username;
                Object.keys(profilsCache).forEach(k => { if(profilsCache[k].pseudo === msg.username) auteurTech = k; });
                const statutAuteur = getStatutEffectif(auteurTech, profilsCache[auteurTech]);

                return (
                  <MessageItem
                    key={msg.id}
                    msg={msg}
                    messagePrecedent={messagePrecedent}
                    monPseudoAffiche={monPseudoAffiche}
                    profilAuteur={profilsCache[auteurTech]}
                    statutAuteur={statutAuteur}
                    messageParent={messageParent}
                    estPremierNonLu={estPremierNonLu}
                    ligneNonLuRef={ligneNonLuRef}
                    messagesRefsMap={messagesRefsMap}
                    messageEnEdition={messageEnEdition}
                    texteEdition={texteEdition}
                    setTexteEdition={setTexteEdition}
                    sauvegarderModification={sauvegarderModification}
                    setMessageEnEdition={setMessageEnEdition}
                    ouvrirMenuContextuel={ouvrirMenuContextuel}
                    gererClicProfil={gererClicProfil}
                    allerAuMessage={allerAuMessage}
                    salonActuel={salonActuel}
                    rechercheQuery={rechercheQuery}
                    toggleReaction={toggleReaction}
                    getAvatarUrlForDisplay={getAvatarUrlForDisplay}
                  />
                );
              })}
              <div ref={finDesMessagesRef} />
            </div>

            {/* ── ZONE DE SAISIE UNIFIÉE ── */}
            <ZoneSaisie 
              nouveauMessage={nouveauMessage}
              setNouveauMessage={setNouveauMessage}
              reponseA={reponseA}
              setReponseA={setReponseA}
              fichierPreview={fichierPreview}
              setFichierPreview={setFichierPreview}
              isUploading={isUploading}
              gifOuvert={gifOuvert}
              setGifOuvert={setGifOuvert}
              gifQuery={gifQuery}
              setGifQuery={setGifQuery}
              gifChargement={gifChargement}
              gifResultats={gifResultats}
              gifTendances={gifTendances}
              emojiOuvert={emojiOuvert}
              setEmojiOuvert={setEmojiOuvert}
              showAideFormat={showAideFormat}
              aideFormatFermeture={aideFormatFermeture}
              toggleAideFormat={toggleAideFormat}
              utilisateursEnTrain={utilisateursEnTrain}
              dernierTexteTypingRef={dernierTexteTypingRef}

              /* Variables dynamiques */
              placeholder={salonActuel.startsWith('dm_') ? 'Message privé...' : `Écrire dans #${salonActuel}...`}
              pseudoActuel={monPseudoAffiche}

              /* Variables des Mentions */
              mentionMenuOuvert={mentionQuery !== null}
              mentionsFiltrees={
                (mentionQuery !== null) ? amis
                  .map(f => {
                    const idAmi = f.requester_id === session.user.id ? f.receiver_id : f.requester_id;
                    return Object.values(profilsCache).find(p => p.id === idAmi);
                  })
                  .filter(p => p && p.pseudo.toLowerCase().includes(mentionQuery.toLowerCase()))
                  .map(p => ({ pseudo: p.pseudo, avatar_url: p.avatar_url })) : []
              }
              mentionIndex={mentionIndex}
              setMentionIndex={setMentionIndex}
              fermerMenuMention={() => setMentionQuery(null)}
              insererMention={(pseudoAmi) => {
                const words = nouveauMessage.split(/\s/);
                words[words.length - 1] = `@${pseudoAmi} `;
                setNouveauMessage(words.join(' '));
                setMentionQuery(null);
                inputMessageRef.current?.focus();
              }}

              /* Références et Handlers */
              inputMessageRef={inputMessageRef}
              emojiTriggerRef={emojiTriggerRef}
              fichierInputRef={fichierInputRef}
              gererFrappe={gererFrappe}
              envoyerMessage={envoyerMessage}
              envoyerFichier={envoyerFichier}
              confirmerEnvoiFichier={confirmerEnvoiFichier}
              ouvrirGif={ouvrirGif}
              rechercherGifs={rechercherGifs}
              envoyerGif={envoyerGif}
              insererEmoji={insererEmoji}
            />
          </>
        ) : (
          /* ── HUB DES AMIS ── */
          <HubAmis 
            ongletAmis={ongletAmis}
            setOngletAmis={setOngletAmis}
            demandesAmis={demandesAmis}
            amis={amis}
            rechercheAmi={rechercheAmi}
            setRechercheAmi={setRechercheAmi}
            ajoutAmiLoading={ajoutAmiLoading}
            envoyerDemandeAmi={envoyerDemandeAmi}
            repondreDemandeAmi={repondreDemandeAmi}
            supprimerAmi={supprimerAmi}
            demarrerDM={demarrerDM}
            getAvatarUrlForDisplay={getAvatarUrlForDisplay}
            getProfilAmi={getProfilAmi}
            getStatutEffectif={getStatutEffectif}
          />
        )}
      </div>
      </div>
      )}
      {/* ── MODALE BIENVENUE (1ère connexion) ── */}
      {showWelcome && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md animate-fade-in" />
          <div className="relative bg-base-100 rounded-3xl shadow-2xl p-8 max-w-sm w-full text-center animate-[modalIn_0.3s_ease_forwards]">
            <div className="text-6xl mb-4">👋</div>
            <h2 className="text-2xl font-black mb-2">Bienvenue !</h2>
            <p className="text-gray-500 text-sm mb-8">Ravi de vous voir ici. Voulez-vous suivre un court guide pour découvrir le fonctionnement de la plateforme ?</p>
            <div className="flex flex-col gap-3">
              <button onClick={() => { setShowWelcome(false); setShowGuide(true); }} className="btn btn-primary w-full shadow-lg font-bold">Suivre le guide</button>
              <button onClick={() => { setShowWelcome(false); localStorage.setItem(`guide_termine_${session.user.id}`, 'true'); }} className="btn btn-ghost w-full">Plus tard</button>
            </div>
          </div>
        </div>
      )}

      {/* ── MODALE GUIDE PAS À PAS ── */}
      {showGuide && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xl animate-fade-in" />
          <div className="relative bg-base-100 rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden animate-[modalIn_0.3s_ease_forwards] border border-white/10">
            
            {/* Barre de progression */}
            <div className="h-1.5 w-full bg-base-300">
              <div className="h-full bg-primary transition-all duration-500" style={{ width: `${((guideStep + 1) / 4) * 100}%` }} />
            </div>

            <div className="p-8 text-center">
              {guideStep === 0 && (
                <div className="animate-fade-in">
                  <div className="w-20 h-20 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-6"><Hash size={40}/></div>
                  <h3 className="text-xl font-black mb-3">La barre des serveurs</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">Sur la gauche, vous trouverez tous vos serveurs. Vous pouvez les organiser dans des dossiers par simple glisser-déposer, ou faire un clic droit pour les gérer.</p>
                </div>
              )}

              {guideStep === 1 && (
                <div className="animate-fade-in">
                  <div className="w-20 h-20 bg-info/10 text-info rounded-2xl flex items-center justify-center mx-auto mb-6"><Compass size={40}/></div>
                  <h3 className="text-xl font-black mb-3">L'Explorateur</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">Cliquez sur la boussole pour découvrir de nouvelles communautés publiques et rejoindre des serveurs qui partagent vos thématiques favorites.</p>
                </div>
              )}

              {guideStep === 2 && (
                <div className="animate-fade-in">
                  <div className="w-20 h-20 bg-success/10 text-success rounded-2xl flex items-center justify-center mx-auto mb-6"><MessageCircle size={40}/></div>
                  <h3 className="text-xl font-black mb-3">Messages Privés</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">L'icône de bulle en haut à gauche vous permet de discuter en privé avec vos amis et de gérer vos demandes d'ajout facilement.</p>
                </div>
              )}

              {guideStep === 3 && (
                <div className="animate-fade-in">
                  <div className="w-20 h-20 bg-warning/10 text-warning rounded-2xl flex items-center justify-center mx-auto mb-6"><Palette size={40}/></div>
                  <h3 className="text-xl font-black mb-3">Personnalisation</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">En cliquant sur l'engrenage en bas à gauche, accédez à vos paramètres pour changer l'apparence du site, votre pseudo et votre statut.</p>
                </div>
              )}

              <div className="flex items-center justify-between mt-10">
                <button onClick={() => guideStep > 0 ? setGuideStep(gs => gs - 1) : terminerGuide()} className="btn btn-ghost btn-sm font-bold">
                  {guideStep === 0 ? 'Quitter' : 'Retour'}
                </button>
                <div className="flex gap-1.5">
                  {[0,1,2,3].map(i => <div key={i} className={`w-2 h-2 rounded-full transition-colors duration-300 ${guideStep === i ? 'bg-primary' : 'bg-base-300'}`} />)}
                </div>
                {guideStep < 3 ? (
                  <button onClick={() => setGuideStep(gs => gs + 1)} className="btn btn-primary btn-sm px-6 shadow-md font-bold">Suivant</button>
                ) : (
                  <button onClick={terminerGuide} className="btn btn-success btn-sm px-6 text-white font-bold shadow-md">C'est parti !</button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
    </AppProvider>
  );
}