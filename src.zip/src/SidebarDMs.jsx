import React from 'react';
import { MessageCircle, Users, X, Settings, LogOut } from 'lucide-react';
import { useAuth } from './contexts/AuthContext';
import { useUI } from './contexts/UIContext'; // 👈 AJOUTE CETTE LIGNE

const STATUTS = {
  en_ligne:  { label: 'En ligne',  dot: 'bg-success',  text: 'text-success' },
  occupe:    { label: 'Occupé',    dot: 'bg-warning',  text: 'text-warning' },
  absent:    { label: 'Absent',    dot: 'bg-error',    text: 'text-error'   },
  invisible: { label: 'Invisible', dot: 'bg-gray-400', text: 'text-gray-400'},
};

const StatutDot = ({ statut, taille = 'w-2.5 h-2.5' }) => {
  if (!statut) return null;
  return <span className={`${taille} rounded-full border-2 border-base-100 ${STATUTS[statut]?.dot || 'bg-gray-400'} flex-shrink-0`} />;
};

export default function SidebarDMs({
  salonActuel,
  changerSalon,
  vueActive,
  demandesAmis,
  salonsPrives,

  getAvatarUrlForDisplay,
  notifications,
  supprimerSalonDM,
  ouvrirParametres,
  demanderConfirmation,
  seDeconnecter
}) {
  // 🧠 Le composant va chercher ses infos lui-même !
  // Avant : const { session, monProfil, pseudo: monPseudoAffiche } = useAuth();
  const { session, monProfil, pseudo: monPseudoAffiche, profilsCache, utilisateursEnLigne, getStatutEffectif } = useAuth();
  const monPseudoTech = session?.user?.email?.split('@')[0];
  const { menuMobileOuvert, fermerMenuMobile } = useUI(); // 👈 Ajout

  return (
   <div className={`w-64 bg-base-300 flex flex-col border-r border-base-100 absolute md:relative z-[110] h-full transition-transform duration-300 md:translate-x-0 ${menuMobileOuvert ? 'translate-x-[72px]' : '-translate-x-full'}`}>
      <div className="p-4 font-bold text-xl border-b border-base-100 flex items-center gap-2">
        <MessageCircle size={24} className="text-primary"/> Messages
      </div>
      
      <div className="flex-1 overflow-y-auto flex flex-col">
        {/* Bouton Amis */}
        <div className="p-3 pb-2 border-b border-base-200/60">
          <button
            onClick={() => { changerSalon(''); fermerMenuMobile(); }}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all ${salonActuel === '' && vueActive === 'chat' ? 'bg-primary text-primary-content font-bold shadow-md' : 'hover:bg-base-200 text-gray-500 hover:text-base-content'}`}
          >
            <Users size={18} className={salonActuel === '' ? 'text-primary-content' : 'text-gray-400'} />
            <span className="flex-1 text-left">Amis</span>
            {demandesAmis.length > 0 && (
              <span className="badge badge-error badge-sm text-[10px] text-white font-bold shadow-sm border-0">{demandesAmis.length}</span>
            )}
          </button>
        </div>

        {/* Liste des Conversations Privées (DMs) */}
        {salonsPrives.length > 0 && (
          <div className="p-3 pt-3">
            <h2 className="text-[11px] font-bold text-gray-400 mb-2 uppercase tracking-wider px-2">Messages Privés</h2>
            <ul className="menu bg-base-300 w-full p-0">
              {salonsPrives.map(contact => {
                const room = `dm_${[monPseudoTech, contact].sort().join('_')}`;
                const profil = profilsCache[contact];
                const statut = getStatutEffectif(contact, profil);
                const displayContact = profil?.pseudo || contact;
                const estSupprime = !profil && !utilisateursEnLigne.includes(contact);
                const isActive = salonActuel === room && vueActive === 'chat';
                
                return (
                  <li key={contact} className="group/dm relative">
                    <a className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors pr-8 ${isActive ? "bg-primary text-primary-content font-bold shadow-md" : "hover:bg-base-200 text-gray-500 hover:text-base-content"}`} onClick={() => { changerSalon(room); fermerMenuMobile(); }}>
                      <div className="relative flex-shrink-0">
                        <img src={getAvatarUrlForDisplay(displayContact)} alt={displayContact} className={`w-6 h-6 rounded-full object-cover ${estSupprime ? 'opacity-40 grayscale' : ''}`} />
                        {statut && <StatutDot statut={statut} taille="w-2.5 h-2.5 absolute -bottom-0.5 -right-0.5 border" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className={`truncate block font-medium ${estSupprime ? 'opacity-60 italic' : ''}`}>{displayContact}</span>
                      </div>
                      {notifications[room] > 0 && <div className="badge badge-error badge-sm text-[10px] font-bold text-white shadow-sm border-0">{notifications[room]}</div>}
                    </a>
                    <button
                      onClick={(e) => { e.stopPropagation(); supprimerSalonDM(contact); }}
                      className={`absolute right-1.5 top-1/2 -translate-y-1/2 p-1 rounded-md opacity-0 group-hover/dm:opacity-100 transition-opacity ${isActive ? 'text-primary-content/60 hover:text-primary-content' : 'text-gray-400 hover:text-error'}`}
                      title="Fermer la conversation">
                      <X size={13} />
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </div>
      
      {/* Barre du Profil en bas */}
      <div className="p-3 border-t border-base-100 bg-base-200 flex items-center gap-2 mt-auto w-full">
        <div className="flex items-center gap-2 flex-1 min-w-0 rounded-lg px-2 py-1.5 group">
          <div className="relative flex-shrink-0">
            <img src={getAvatarUrlForDisplay(monPseudoAffiche)} alt="Moi" className="w-8 h-8 rounded-full object-cover" />
            {monProfil?.statut !== 'invisible' && <StatutDot statut={monProfil?.statut || 'en_ligne'} taille="w-2.5 h-2.5 absolute -bottom-0.5 -right-0.5 border" />}
          </div>
          <div className="min-w-0 text-left flex-1">
            <div className="text-sm font-bold truncate">{monPseudoAffiche}</div>
            <div className={`text-[10px] font-medium ${STATUTS[monProfil?.statut || 'en_ligne']?.text}`}>
              {STATUTS[monProfil?.statut || 'en_ligne']?.label}
            </div>
          </div>
          <button onClick={ouvrirParametres} className="flex-shrink-0 p-1.5 rounded-md text-gray-400 hover:text-base-content hover:bg-base-300 transition-colors cursor-pointer" title="Paramètres">
            <Settings size={16} />
          </button>
        </div>
        <button onClick={() => demanderConfirmation("Se déconnecter ?", seDeconnecter, false)}
          className="btn btn-ghost btn-sm btn-circle text-error opacity-60 hover:opacity-100 flex-shrink-0" title="Se déconnecter">
          <LogOut size={15} />
        </button>
      </div>
    </div>
  );
}