import { useEffect, useRef } from 'react';
import data from '@emoji-mart/data';
import { Picker } from 'emoji-mart';

export default function EmojiPicker({ triggerRef, onSelect, onClose }) {
  const containerRef = useRef(null);
  const mountedRef = useRef(false);

  useEffect(() => {
    // Guard against double-mount in React Strict Mode
    if (mountedRef.current) return;
    mountedRef.current = true;

    // Position
    // Positionnement intelligent
    const btn = triggerRef?.current;
    if (btn && containerRef.current) {
      const r = btn.getBoundingClientRect();
      const W = 352, H = 400; // Dimensions approximatives du picker
      const vw = window.innerWidth, vh = window.innerHeight;
      
      // On s'aligne sur le bord GAUCHE du bouton (pour s'étendre vers la droite)
      let left = r.left;
      
      // Si le picker dépasse à DROITE de l'écran, on le décale vers la gauche
      if (left + W > vw - 10) {
        left = vw - W - 10;
      }
      
      // Sécurité si on est trop près du bord GAUCHE (ex: sidebar)
      if (left < 10) left = 10;
      
      let top = r.top - H - 8; // S'ouvre vers le haut par défaut
      if (top < 8) top = r.bottom + 8; // S'ouvre vers le bas s'il n'y a pas de place en haut
      
      containerRef.current.style.top = top + 'px';
      containerRef.current.style.left = left + 'px';
      containerRef.current.style.opacity = '1';
    }

    const picker = new Picker({
      data,
      locale: 'fr',
      theme: 'auto',
      previewPosition: 'none',
      skinTonePosition: 'none',
      onEmojiSelect: (emoji) => {
        onSelect(emoji.native);
        // Reste ouvert pour sélections multiples
      },
      onClickOutside: () => {},
    });

    containerRef.current?.appendChild(picker);

    return () => {
      if (containerRef.current) {
        containerRef.current.innerHTML = '';
      }
      mountedRef.current = false;
    };
  }, []);

  // Ferme sur clic en dehors
  useEffect(() => {
    const handler = (e) => {
      if (
        containerRef.current && !containerRef.current.contains(e.target) &&
        triggerRef?.current && !triggerRef.current.contains(e.target)
      ) onClose();
    };
    setTimeout(() => window.addEventListener('mousedown', handler), 0);
    return () => window.removeEventListener('mousedown', handler);
  }, [onClose]);

  return (
    <div
      ref={containerRef}
      className="fixed z-[300]"
      style={{ opacity: 0, transition: 'opacity 0.15s ease' }}
    />
  );
}