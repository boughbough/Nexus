import React, { createContext, useContext, useState } from 'react';

const UIContext = createContext();

export function UIProvider({ children, ajouterToast }) {
  // 📱 Nouvel état pour le mobile
  const [menuMobileOuvert, setMenuMobileOuvert] = useState(false);
  const toggleMenuMobile = () => setMenuMobileOuvert(prev => !prev);
  const fermerMenuMobile = () => setMenuMobileOuvert(false);

  // On ajoute ces fonctions au "cerveau"
  const value = { ajouterToast, menuMobileOuvert, toggleMenuMobile, fermerMenuMobile };

  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
}

export const useUI = () => useContext(UIContext);