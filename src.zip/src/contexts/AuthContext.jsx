import React, { createContext, useContext } from 'react';

const AuthContext = createContext();

export function AuthProvider({ children, session, monProfil, utilisateursEnLigne, profilsCache, getStatutEffectif }) {
  const pseudo = monProfil?.pseudo || session?.user?.email?.split('@')[0];
  
  const value = {
    session,
    monProfil,
    pseudo,
    isAuthenticated: !!session,
    // 👇 Le radar en temps réel 👇
    utilisateursEnLigne,
    profilsCache,
    getStatutEffectif
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);