import React from 'react';
import { MessageCircle, UserPlus } from 'lucide-react';
import { supabase } from './supabase';

const STATUTS = {
  en_ligne:  { label: 'En ligne',  dot: 'bg-success',  text: 'text-success' },
  occupe:    { label: 'Occupé',    dot: 'bg-warning',  text: 'text-warning' },
  absent:    { label: 'Absent',    dot: 'bg-error',    text: 'text-error'   },
  invisible: { label: 'Invisible', dot: 'bg-gray-400', text: 'text-gray-400'},
};

const StatutDot = ({ statut, taille = 'w-2.5 h-2.5' }) => {
  if (!statut) return null;
  return <span className={`${taille} rounded-full border-2 border-base-100 ${STATUTS[statut]?.dot || 'bg-gray-400'} flex-shrink-0`} />;
};

export default function ProfilPopover({
  profilPopover,
  setProfilPopover,
  getAvatarUrlForDisplay,
  getStatutEffectif,
  demarrerDM,
  session,
  amis,
  demandesAmis,
  ajouterToast
}) {
  if (!profilPopover) return null;

  const handleAjouterAmi = async () => {
    await supabase.from('friendships').insert({ 
        requester_id: session.user.id, 
        receiver_id: profilPopover.profil.id, 
        status: 'pending' 
    });
    setProfilPopover(null);
    ajouterToast("Demande envoyée !");
  };

  const statut = getStatutEffectif(profilPopover.username, profilPopover.profil);

  return (
    <>
      {/* Fond flouté cliquable pour fermer */}
      <div className="fixed inset-0 z-40 backdrop-blur-[2px]" onClick={() => setProfilPopover(null)} />
      
      {/* Conteneur de la bulle */}
      <div className="popover-appear fixed z-50 bg-base-100 rounded-xl shadow-xl border border-base-200 w-56 overflow-hidden"
        style={{ top: profilPopover.top, left: profilPopover.left }}>
        
        {/* En-tête (Avatar + Pseudo + Statut) */}
        <div className="bg-gradient-to-r from-primary/15 to-transparent p-4 pb-3 flex items-center gap-3">
          <div className="relative flex-shrink-0">
            <img src={getAvatarUrlForDisplay(profilPopover.displayUsername)} className="w-12 h-12 rounded-full border-2 border-base-100 shadow object-cover" alt={profilPopover.displayUsername} />
            {statut && <StatutDot statut={statut} taille="w-3.5 h-3.5 absolute -bottom-0.5 -right-0.5 border-2" />}
          </div>
          
          <div className="min-w-0">
            <div className="font-bold text-sm truncate">{profilPopover.displayUsername}</div>
            {statut ? (
              <div className={`text-xs font-medium flex items-center gap-1 mt-0.5 ${STATUTS[statut].text}`}>{STATUTS[statut].label}</div>
            ) : (
              <div className="text-xs text-gray-400 mt-0.5">Hors ligne</div>
            )}
          </div>
        </div>
        
        {/* Bio (si existante) */}
        {profilPopover.profil?.bio && (
          <div className="px-4 py-2 text-xs text-gray-500 italic border-t border-base-200 line-clamp-3">
            {profilPopover.profil.bio}
          </div>
        )}
        
        {/* Boutons d'action */}
        <div className="px-3 pb-3 pt-2">
          <button onClick={() => demarrerDM(profilPopover.username)} className="btn btn-primary btn-sm w-full">
            <MessageCircle size={14} /> Message privé
          </button>
          
          {(() => {
            if (profilPopover.profil?.id === session.user.id) return null; // C'est nous-même
            const relation = [...amis, ...demandesAmis].find(f => f.requester_id === profilPopover.profil?.id || f.receiver_id === profilPopover.profil?.id);
            
            if (relation?.status === 'accepted') return <button className="btn btn-outline btn-sm w-full mt-2" disabled>✓ Déjà amis</button>;
            if (relation?.status === 'pending') return <button className="btn btn-outline btn-sm w-full mt-2" disabled>⏳ En attente</button>;
            
            return (
              <button onClick={handleAjouterAmi} className="btn btn-secondary btn-sm w-full mt-2">
                <UserPlus size={14} /> Ajouter en ami
              </button>
            );
          })()}
        </div>
      </div>
    </>
  );
}