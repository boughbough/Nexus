import React from 'react';
import { AuthProvider } from './contexts/AuthContext';
import { UIProvider } from './contexts/UIContext';

export default function AppProvider({ children, session, monProfil, ajouterToast, utilisateursEnLigne, profilsCache, getStatutEffectif }) {
  return (
    <AuthProvider 
      session={session} 
      monProfil={monProfil} 
      utilisateursEnLigne={utilisateursEnLigne} 
      profilsCache={profilsCache} 
      getStatutEffectif={getStatutEffectif}
    >
      <UIProvider ajouterToast={ajouterToast}>
        {children}
      </UIProvider>
    </AuthProvider>
  );
}