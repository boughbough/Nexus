import { useState, useEffect } from 'react';
import { X, Copy, RefreshCw, Settings, LogOut, Users, Trash2 } from 'lucide-react';
import { supabase } from './supabase';

import TabGeneral from './TabGeneral';
import TabMembres from './TabMembres';
import ModaleSuppressionServeur from './ModaleSuppressionServeur';

export default function ServerSettings({ server, monRole, session, monProfil, onClose, onServerDeleted, onServerUpdated, ajouterToast, initialTab }) {
  const [onglet, setOnglet] = useState(initialTab || 'general');
  const [membres, setMembres] = useState([]);
  const [channels, setChannels] = useState([]);
  const [newChannel, setNewChannel] = useState('');
  const [showDelModal, setShowDelModal] = useState(false);
  const [delLoading, setDelLoading] = useState(false);

  const isAdmin = ['owner', 'admin'].includes(monRole);

  useEffect(() => { chargerMembres(); chargerChannels(); }, []);

  const chargerMembres = async () => {
    const { data } = await supabase.from('server_members').select('*').eq('server_id', server.id).order('joined_at');
    setMembres(data || []);
  };

  const chargerChannels = async () => {
    const { data } = await supabase.from('server_channels').select('*').eq('server_id', server.id).order('position');
    setChannels(data || []);
  };

  const executerSuppression = async () => {
    setDelLoading(true);
    const { error } = await supabase.from('servers').delete().eq('id', server.id);
    if (!error) { ajouterToast("Le serveur a été désintégré 💥"); onServerDeleted(server.id); }
    else { ajouterToast("Erreur suppression", "error"); setDelLoading(false); }
  };

  const changerRole = async (userId, role) => {
    const { data } = await supabase.from('server_members').update({ role }).eq('server_id', server.id).eq('user_id', userId).select();
    if (data?.length) { chargerMembres(); ajouterToast('Rôle mis à jour'); }
    else { ajouterToast('Permission refusée', 'error'); }
  };

  const ajouterChannel = async () => {
    if (!newChannel.trim()) return;
    const clean = newChannel.trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');
    await supabase.from('server_channels').insert({ server_id: server.id, name: clean, position: channels.length });
    chargerChannels(); setNewChannel('');
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-base-100 rounded-2xl shadow-2xl w-full max-w-2xl mx-4 z-10 overflow-hidden flex animate-[modalIn_0.2s_ease_forwards]" style={{maxHeight: '85vh'}}>
        
        {/* Sidebar */}
        <div className="w-48 bg-base-200 p-3 flex flex-col gap-1 shrink-0">
          <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-2 mb-2 truncate">{server.name}</div>
          {[
            { id: 'general', label: 'Général', icon: Settings, show: isAdmin },
            { id: 'channels', label: 'Salons', icon: Settings, show: isAdmin },
            { id: 'membres', label: 'Membres', icon: Users, show: true },
          ].filter(o => o.show).map(o => (
            <button key={o.id} onClick={() => setOnglet(o.id)} className={`flex items-center gap-2 px-2 py-2 rounded-lg text-sm ${onglet === o.id ? 'bg-primary text-primary-content' : 'hover:bg-base-300'}`}>
              <o.icon size={15} /> {o.label}
            </button>
          ))}
          <div className="flex-1" />
          {monRole === 'owner' 
            ? <button onClick={() => setShowDelModal(true)} className="btn btn-ghost btn-sm text-error hover:bg-error/10"><Trash2 size={15}/> Supprimer</button>
            : <button onClick={onClose} className="btn btn-ghost btn-sm text-error hover:bg-error/10"><LogOut size={15}/> Quitter</button>
          }
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-lg font-bold">Paramètres</h2>
            <button onClick={onClose} className="btn btn-ghost btn-sm btn-circle"><X size={16}/></button>
          </div>

          {onglet === 'general' && <TabGeneral server={server} onUpdate={onServerUpdated} ajouterToast={ajouterToast} />}
          
          {onglet === 'membres' && <TabMembres membres={membres} monRole={monRole} session={session} onRoleChange={changerRole} onKick={(id, p) => ajouterToast("Kick non implémenté", "info")} />}

          {onglet === 'channels' && (
            <div className="flex flex-col gap-3">
              {channels.map(ch => <div key={ch.id} className="bg-base-200 p-2 rounded-lg flex items-center gap-2"># {ch.name}</div>)}
              <div className="flex gap-2 mt-4">
                <input className="input input-bordered input-sm flex-1" value={newChannel} onChange={e => setNewChannel(e.target.value)} placeholder="nouveau-salon" />
                <button onClick={ajouterChannel} className="btn btn-primary btn-sm">Créer</button>
              </div>
            </div>
          )}
        </div>
      </div>

      <ModaleSuppressionServeur server={server} isOpen={showDelModal} onClose={() => setShowDelModal(false)} onConfirm={executerSuppression} loading={delLoading} />
    </div>
  );
}