import { useState, useEffect, useRef } from 'react';
import MessageItem from './MessageItem';
import { Hash, Send, Settings,Info, Plus, Loader2, LogOut, ImagePlus, X, Reply, Trash, Pencil, Users, Smile, Search, ArrowDown, FileText, FileVideo, File, Music, Crown, ShieldCheck, Shield, User, Pin, Menu } from 'lucide-react';
import { supabase } from './supabase';
import ServerSettings from './ServerSettings';
import ReactMarkdown from 'react-markdown';
import EmojiPicker from './EmojiPicker';

import ZoneSaisie from './ZoneSaisie';
import PanneauMembres from './PanneauMembres';
import PanneauEpingles from './PanneauEpingles';
// On ajoute "/contexts/" car le fichier est dans ce sous-dossier
import MessageSkeleton from "./contexts/MessageSkeleton";
import { useAuth } from './contexts/AuthContext';
import { useUI } from './contexts/UIContext';


export default function ServerView({ server: initialServer, initialChannel, profilsCache, getStatutEffectif, onLeave, onUserClick, getAvatarUrl, notifications, onChannelSelect, onOpenParametres, onLogout }) {
  const [channels, setChannels] = useState([]);
  const [channelsLoaded, setChannelsLoaded] = useState(false); // 👈 Le capteur
  const [channelActuel, setChannelActuel] = useState(initialChannel);
  const [server, setServer] = useState(initialServer); // 👈 AJOUTE CETTE LIGNE ICI
  const [messages, setMessages] = useState([]);
  const [membres, setMembres] = useState([]);
  const [epinglesPanel, setEpinglesPanel] = useState(false);
  const [monRole, setMonRole] = useState('member');
  const estAdmin = ['owner', 'admin'].includes(monRole);
  const estModerateur = ['owner', 'admin', 'moderator'].includes(monRole);
  // ── ÉTATS MENTIONS ──
  const [mentionMenu, setMentionMenu] = useState({ ouvert: false, recherche: '', index: -1 });
  const [membresFiltres, setMembresFiltres] = useState([]);
  const [mentionIndex, setMentionIndex] = useState(0); // 👈 NOUVEAU : Garde en mémoire qui est sélectionné
  const { session, monProfil, pseudo } = useAuth();
  const { ajouterToast, toggleMenuMobile } = useUI();
  const [nouveauMessage, setNouveauMessage] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [settingsOuvert, setSettingsOuvert] = useState(false);
  const [ongletInitialSettings, setOngletInitialSettings] = useState('general'); // 👈 Ajout de la variable d'onglet
  const [reponseA, setReponseA] = useState(null);
  const [messageEnEdition, setMessageEnEdition] = useState(null);
  const [texteEdition, setTexteEdition] = useState('');
  const [membresPanel, setMembresPanel] = useState(false);
  const [chargement, setChargement] = useState(false);
  // 👇 NOUVEAU : États pour l'indicateur de frappe
  const [utilisateursEnTrain, setUtilisateursEnTrain] = useState([]);
  const canalTypingRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const dernierTexteTypingRef = useRef(null);
  const timeoutFrappe = useRef({}); // 👈 Ajoute ça en haut avec tes refs

  const [showAideFormat, setShowAideFormat] = useState(false);
  const [aideFormatFermeture, setAideFormatFermeture] = useState(false);

  const toggleAideFormat = () => {
    if (showAideFormat) {
      setAideFormatFermeture(true);
      setTimeout(() => { setShowAideFormat(false); setAideFormatFermeture(false); }, 150);
    } else {
      setShowAideFormat(true);
    }
  };

  // Fichiers et Prévisualisation
  const [fichierPreview, setFichierPreview] = useState(null);
  const fichierInputRef = useRef(null);

  // GIFs et Emojis
  const [gifOuvert, setGifOuvert] = useState(false);
  const [emojiOuvert, setEmojiOuvert] = useState(false);
  const [gifQuery, setGifQuery] = useState('');
  const [gifResultats, setGifResultats] = useState([]);
  const [gifTendances, setGifTendances] = useState([]);
  const [gifChargement, setGifChargement] = useState(false);
  const emojiTriggerRef = useRef(null);
  const inputMessageRef = useRef(null);
  const GIPHY_KEY = import.meta.env.VITE_GIPHY_KEY;

  // Clic Droit (Réactions)
  const [menuContextuel, setMenuContextuel] = useState(null);
  const [menuFermeture, setMenuFermeture] = useState(false);
  const menuFermetureTimeout = useRef(null);
  const emojisDispos = ["👍", "❤️", "😂", "🔥", "👀"];

  const conteneurRef = useRef(null);
  const ligneNonLuRef = useRef(null); // 👈 AJOUTE CETTE LIGNE ICI
  const messagesRefsMap = useRef({});
  const lastTypeTime = useRef(0);

  const allerAuMessage = (msgId) => {
    const el = messagesRefsMap.current[msgId];
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('ring-2', 'ring-primary', 'rounded-xl', 'transition-all', 'duration-500');
      setTimeout(() => el.classList.remove('ring-2', 'ring-primary', 'rounded-xl'), 2000);
    }
  };

  const [messagesEpingles, setMessagesEpingles] = useState([]);


  // ── UTILITAIRES DE FICHIERS ET DATES ──
  const getFileIcon = (fileType) => {
    if (!fileType) return File;
    if (fileType.startsWith('video/')) return FileVideo;
    if (fileType.startsWith('audio/')) return Music;
    if (fileType === 'application/pdf' || fileType.includes('word') || fileType.includes('document')) return FileText;
    return File;
  };

  const getFileColor = (fileType) => {
    if (!fileType) return 'text-gray-400';
    if (fileType.startsWith('video/')) return 'text-blue-400';
    if (fileType.startsWith('audio/')) return 'text-purple-400';
    if (fileType === 'application/pdf') return 'text-red-400';
    if (fileType.includes('word') || fileType.includes('document')) return 'text-blue-500';
    return 'text-gray-400';
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '';
    if (bytes < 1024) return bytes + ' o';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' Ko';
    return (bytes / (1024 * 1024)).toFixed(1) + ' Mo';
  };

  const formaterDateSeparateur = (dateISO) => {
    const d = new Date(dateISO), auj = new Date(), hier = new Date();
    hier.setDate(auj.getDate() - 1);
    if (d.toDateString() === auj.toDateString()) return "Aujourd'hui";
    if (d.toDateString() === hier.toDateString()) return "Hier";
    return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  };

  const estUtilisateurSupprime = (nom) => nom === '[supprimé]';

  // ── CHARGEMENT DES DONNÉES ──
  useEffect(() => { chargerChannels(); chargerMembres(); }, [server.id]);

  // 👇 NOUVEAU : Écouteur pour le typing dans les salons
  useEffect(() => {
    if (!channelActuel) return;
    const canalBroadcast = supabase.channel(`broadcast-typing-${server.id}`);
    
    canalBroadcast
      .on('broadcast', { event: 'typing' }, ({ payload }) => {
        const { pseudo: p, salon, typing } = payload;
        if (!p || p === pseudo || salon !== channelActuel.id) return;
        
        // On nettoie le chrono proprement avec useRef (pas de window)
        if (timeoutFrappe.current[p]) {
          clearTimeout(timeoutFrappe.current[p]);
        }
        
        if (typing) {
          setUtilisateursEnTrain(prev => prev.includes(p) ? prev : [...prev, p]);
          // On relance un chrono de 3 secondes
          timeoutFrappe.current[p] = setTimeout(() => {
            setUtilisateursEnTrain(prev => prev.filter(x => x !== p));
          }, 3000);
        } else {
          setUtilisateursEnTrain(prev => prev.filter(x => x !== p));
        }
      })
      .subscribe((status) => { 
        if (status === 'SUBSCRIBED') canalTypingRef.current = canalBroadcast; 
      });
    
    return () => {
      supabase.removeChannel(canalBroadcast);
      canalTypingRef.current = null;
    };
  }, [server.id, channelActuel?.id, pseudo]);

  const gererFrappe = (e) => {
    const val = e.target.value;
    setNouveauMessage(val);

    // --- 1. L'INDICATEUR DE FRAPPE (Corrigé et Anti-Spam) ---
    const now = Date.now();
    if (now - lastTypeTime.current > 2000) {
      if (canalTypingRef.current) { // 👈 Le bon canal !
        canalTypingRef.current.send({
          type: 'broadcast',
          event: 'typing',
          payload: { 
            pseudo: pseudo, 
            salon: channelActuel?.id, // 👈 Indispensable pour que l'autre le reçoive !
            typing: true 
          } 
        });
      }
      lastTypeTime.current = now;
    }

    // --- 2. LA LOGIQUE DES MENTIONS (@) (Restaurée) ---
    const cursorPosition = e.target.selectionStart;
    const textBeforeCursor = val.slice(0, cursorPosition);
    const words = textBeforeCursor.split(/\s/);
    const lastWord = words[words.length - 1];

    if (lastWord.startsWith('@')) {
      setMentionMenu({ ouvert: true, recherche: lastWord.slice(1).toLowerCase(), index: 0 });
      const search = lastWord.slice(1).toLowerCase();
      
      // 👇 La nouvelle ligne : on exclut le "pseudo" actuel ! 👇
      const filtres = membres.filter(m => m.pseudo !== pseudo && m.pseudo.toLowerCase().includes(search));
      
      setMembresFiltres(filtres);
    } else {
      setMentionMenu({ ouvert: false, recherche: '', index: -1 });
    }
  };

  const insererMention = (membrePseudo) => {
    const debut = nouveauMessage.slice(0, mentionMenu.index);
    const fin = nouveauMessage.slice(mentionMenu.index + mentionMenu.recherche.length + 1);
    setNouveauMessage(`${debut}@${membrePseudo} ${fin}`);
    setMentionMenu({ ouvert: false, recherche: '', index: -1 });
    setTimeout(() => inputMessageRef.current?.focus(), 10);
  };

  useEffect(() => {
    if (!channelActuel) return;
    const canal = supabase.channel(`server-${server.id}-ch-${channelActuel.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `channel_id=eq.${channelActuel.id}` },
        ({ new: msg }) => { setMessages(prev => [...prev, { ...msg, reactions: [] }]); scrollBas(); })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages', filter: `channel_id=eq.${channelActuel.id}` },
        ({ old }) => setMessages(prev => prev.filter(m => m.id !== old.id)))
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `channel_id=eq.${channelActuel.id}` },
        ({ new: msg }) => {
          setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, ...msg } : m));
          // 👇 NOUVEAU : On met à jour le panneau des épingles en temps réel !
          setMessagesEpingles(prev => {
            if (msg.pinned && !prev.find(p => p.id === msg.id)) return [msg, ...prev].sort((a,b) => new Date(b.created_at) - new Date(a.created_at));
            if (!msg.pinned) return prev.filter(p => p.id !== msg.id);
            return prev.map(p => p.id === msg.id ? msg : p);
          });
        })
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'reactions' }, ({ new: r }) => {
        setMessages(prev => prev.map(m => {
          if (m.id !== r.message_id) return m;
          const dejaPresent = m.reactions?.find(rx => rx.username === r.username && rx.emoji === r.emoji);
          if (dejaPresent) {
            return { ...m, reactions: m.reactions.map(rx => rx === dejaPresent ? r : rx) };
          }
          return { ...m, reactions: [...(m.reactions || []), r] };
        }));
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'reactions' }, ({ old: r }) => {
        setMessages(prev => prev.map(m => ({ ...m, reactions: (m.reactions || []).filter(rx => rx.id !== r.id) })));
      })
      .subscribe();
    return () => supabase.removeChannel(canal);
  }, [channelActuel?.id]);

  useEffect(() => {
    const canal = supabase.channel(`server-channels-${server.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'server_channels', filter: `server_id=eq.${server.id}` }, (payload) => {
        chargerChannels(); // Recharge la liste
        // Si le salon actuel vient d'être supprimé, on reset pour afficher la page d'accueil
        if (payload.eventType === 'DELETE' && payload.old.id === channelActuel?.id) {
          setChannelActuel(null);
        }
      })
      .subscribe();
    return () => supabase.removeChannel(canal);
  }, [server.id, channelActuel]);

  // Écoute les changements de membres (rôles, départs, arrivées) en temps réel
  useEffect(() => {
    const canalMembres = supabase.channel(`server-members-${server.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'server_members', filter: `server_id=eq.${server.id}` }, () => {
        chargerMembres(); // On recharge proprement la liste quand un rôle change
      })
      .subscribe();
    return () => supabase.removeChannel(canalMembres);
  }, [server.id]);

  const scrollBas = () => setTimeout(() => { if (conteneurRef.current) conteneurRef.current.scrollTop = conteneurRef.current.scrollHeight; }, 80);

  const chargerChannels = async () => {
    const { data } = await supabase.from('server_channels').select('*').eq('server_id', server.id).order('position');
    setChannels(data || []);
    if (!channelActuel && data?.length > 0) setChannelActuel(data[0]);
    setChannelsLoaded(true); // 👈 On prévient que c'est bon, on a la réponse !
  };

  const chargerMembres = async () => {
    const { data } = await supabase.from('server_members').select('*').eq('server_id', server.id);
    setMembres(data || []);
    const moi = data?.find(m => m.user_id === session.user.id);
    setMonRole(moi?.role || 'member');
  };

  const chargerMessages = async () => {
    setChargement(true);
    const { data } = await supabase.from('messages').select('*, reactions(*)').eq('channel_id', channelActuel.id).order('created_at', { ascending: false }).limit(50);
    setMessages((data || []).reverse());
    setChargement(false);
    scrollBas();
  };

  useEffect(() => {
    if (channelActuel) {
      chargerMessages();
      onChannelSelect?.(channelActuel); // 👈 On prévient App.jsx pour effacer la notif !
    }
  }, [channelActuel?.id]);

  const chargerEpingles = async () => {
    if (!channelActuel) return;
    const { data } = await supabase
      .from('messages')
      .select('*')
      .eq('channel_id', channelActuel.id)
      .eq('pinned', true)
      .order('created_at', { ascending: false });
    setMessagesEpingles(data || []);
  };

  // On recharge les épingles quand on change de salon ou quand le panneau s'ouvre
  // On recharge les épingles quand on change de salon ou quand le panneau s'ouvre
  useEffect(() => {
    if (epinglesPanel) chargerEpingles();
  }, [channelActuel?.id, epinglesPanel]);

  // ── FONCTIONS CLIC DROIT & RÉACTIONS ──
  const ouvrirMenuContextuel = (e, message) => {
    e.preventDefault();
    if (menuFermetureTimeout.current) clearTimeout(menuFermetureTimeout.current);
    const decalageY = window.innerHeight - e.clientY < 220 ? e.clientY - 220 : e.clientY;
    const decalageX = window.innerWidth - e.clientX < 200 ? e.clientX - 200 : e.clientX;
    setMenuFermeture(false);
    setMenuContextuel({ message, x: decalageX, y: decalageY });
  };
  
  const fermerMenuContextuel = () => {
    setMenuFermeture(true);
    menuFermetureTimeout.current = setTimeout(() => { setMenuContextuel(null); setMenuFermeture(false); }, 150);
  };
  
  useEffect(() => {
    if (!menuContextuel) return;
    const handler = (e) => { if (e.button !== 2) fermerMenuContextuel(); };
    window.addEventListener("mousedown", handler);
    return () => window.removeEventListener("mousedown", handler);
  }, [menuContextuel]);

  const toggleReaction = async (messageId, emoji) => {
    const existing = messages.find(m => m.id === messageId)?.reactions?.find(r => r.username === pseudo && r.emoji === emoji);
    if (existing) {
      setMessages(prev => prev.map(m => m.id === messageId ? { ...m, reactions: m.reactions.filter(r => r.id !== existing.id) } : m));
      await supabase.from("reactions").delete().eq("id", existing.id);
    } else {
      const fakeReaction = { id: Date.now(), message_id: messageId, username: pseudo, emoji };
      setMessages(prev => prev.map(m => m.id === messageId ? { ...m, reactions: [...(m.reactions || []), fakeReaction] } : m));
      await supabase.from("reactions").insert([{ message_id: messageId, username: pseudo, emoji }]);
    }
  };

  // ── FONCTIONS GIFS ET EMOJIS ──
  const ouvrirGif = async () => {
    setGifOuvert(v => !v);
    if (gifTendances.length === 0) {
      setGifChargement(true);
      const res = await fetch(`https://api.giphy.com/v1/gifs/trending?api_key=${GIPHY_KEY}&limit=24&rating=g`);
      setGifTendances((await res.json()).data || []);
      setGifChargement(false);
    }
  };
  
  const rechercherGifs = async (query) => {
    setGifQuery(query);
    if (!query.trim()) { setGifResultats([]); return; }
    setGifChargement(true);
    const res = await fetch(`https://api.giphy.com/v1/gifs/search?api_key=${GIPHY_KEY}&q=${encodeURIComponent(query)}&limit=24&rating=g`);
    setGifResultats((await res.json()).data || []);
    setGifChargement(false);
  };
  
  const envoyerGif = async (gif) => {
    const url = gif.images.original.url;
    setGifOuvert(false);
    await supabase.from('messages').insert([{ content: '', username: pseudo, room: `server-${server.id}-${channelActuel.id}`, server_id: server.id, channel_id: channelActuel.id, image_url: url }]);
    scrollBas();
  };

  const insererEmoji = (emoji) => {
    setNouveauMessage(prev => prev + emoji);
    setTimeout(() => {
      const input = inputMessageRef.current;
      if (input) {
        input.focus();
        const len = input.value.length;
        input.setSelectionRange(len, len);
      }
    }, 0);
  };

  // Écouteur pour ouvrir les paramètres depuis la barre latérale
  // Écouteur pour ouvrir les paramètres depuis la barre latérale
  useEffect(() => {
    const handleOpenSettings = () => {
      setOngletInitialSettings(estAdmin ? 'general' : 'membres');
      setSettingsOuvert(true);
    };
    window.addEventListener('open-server-settings', handleOpenSettings);
    return () => window.removeEventListener('open-server-settings', handleOpenSettings);
  }, [estAdmin]);

  // ── ENVOI DE MESSAGES ET FICHIERS ──
  const dernierEnvoiRef = useRef(0);
  const envoyerMessage = async () => {
    if (fichierPreview) { await confirmerEnvoiFichier(); return; }
    if (!nouveauMessage.trim() || !channelActuel) return;

    // On cherche tous les @Pseudo et on les met dans une liste
    const regexMention = /@(\w+)/g;
    const mentionsTrouvees = [...nouveauMessage.matchAll(regexMention)].map(m => m[1]);

    const texte = nouveauMessage;
    setNouveauMessage(''); setReponseA(null);
    
    await supabase.from('messages').insert([{ 
      content: texte, 
      username: pseudo, 
      room: `server-${server.id}-${channelActuel.id}`, 
      server_id: server.id, 
      channel_id: channelActuel.id,
      reply_to_id: reponseA?.id || null,
      mentions: mentionsTrouvees // 👈 C'est ce qui active le jaune chez l'autre !
    }]);
    scrollBas();
  };

  const envoyerFichier = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    event.target.value = '';
    const MAX = 50 * 1024 * 1024;
    if (file.size > MAX) { ajouterToast('Fichier trop lourd (max 50 Mo)', 'error'); return; }
    const url = URL.createObjectURL(file);
    setFichierPreview({ file, url, type: file.type });
  };

  const confirmerEnvoiFichier = async () => {
    if (!fichierPreview || !channelActuel) return;
    setIsUploading(true);
    const { file, type } = fichierPreview;
    const ext = file.name.split('.').pop().toLowerCase();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${ext}`;
    const bucket = type.startsWith('image/') ? 'chat-images' : 'chat-files';
    const { error } = await supabase.storage.from(bucket).upload(`server-${server.id}/${fileName}`, file);
    
    if (error) { ajouterToast('Erreur upload : ' + error.message, 'error'); setIsUploading(false); return; }
    
    const texte = nouveauMessage;
    const reponse = reponseA?.id || null;
    setNouveauMessage(''); setReponseA(null);

    const { data: { publicUrl } } = supabase.storage.from(bucket).getPublicUrl(`server-${server.id}/${fileName}`);
    await supabase.from('messages').insert([{ 
      content: texte, 
      username: pseudo, 
      room: `server-${server.id}-${channelActuel.id}`, 
      server_id: server.id, 
      channel_id: channelActuel.id, 
      image_url: publicUrl, 
      file_name: file.name, 
      file_type: type,
      reply_to_id: reponse
    }]);
    
    if (fichierPreview.url) {
      URL.revokeObjectURL(fichierPreview.url);
    }
    
    setIsUploading(false);
    setFichierPreview(null);
    scrollBas();
  };

  const supprimerMessage = async (id) => {
    // 1. Animation de disparition (Optimistic UI)
    const el = messagesRefsMap.current[id];
    if (el) {
      el.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
      el.style.opacity = '0';
      el.style.transform = 'scale(0.95)';
    }

    // 2. Laisse l'animation se jouer, puis demande la suppression
    setTimeout(async () => {
      const { data, error } = await supabase
        .from('messages')
        .delete()
        .eq('id', id)
        .select(); // 👈 Obligatoire pour savoir si Supabase a vraiment supprimé !

      // 3. Gestion de l'erreur (Le fameux fantôme)
      if (error || !data || data.length === 0) {
        if (el) { 
          el.style.opacity = '1'; 
          el.style.transform = 'scale(1)'; 
        }
        ajouterToast("Refusé : Vous n'avez pas l'autorisation de supprimer ceci.", 'error');
      }
    }, 300);
  };

  // ── 1. NOUVEAU TOGGLE PIN SÉCURISÉ ──
  const togglePin = async (messageId, estEpingeleactuellement) => {
    const { data, error } = await supabase
      .from('messages')
      .update({ pinned: !estEpingeleactuellement })
      .eq('id', messageId)
      .select(); // 👈 Obligatoire pour vérifier que Supabase a vraiment fait l'action

    if (error) {
      ajouterToast(`Erreur : ${error.message}`, "error");
    } else if (!data || data.length === 0) {
      // Si la RLS bloque l'action, Supabase ne renvoie pas d'erreur, mais renvoie un tableau vide !
      ajouterToast("Refusé : Vérifiez vos règles de sécurité RLS.", "error");
    } else {
      ajouterToast(estEpingeleactuellement ? "Message désépinglé" : "Message épinglé !");
    }
  };

  // ── 2. NOUVELLE SAUVEGARDE ÉDITION (Correction bug) ──
  const sauvegarderEdition = async (id) => {
    if (!texteEdition.trim()) return;
    
    const { error } = await supabase
      .from('messages')
      .update({ 
        content: texteEdition, 
        updated_at: new Date().toISOString() // 👈 On renvoie la date du jour !
      })
      .eq('id', id);
      
    if (error) {
      ajouterToast(`Erreur modification : ${error.message}`, "error");
    } else {
      setMessageEnEdition(null);
    }
  };

  


  const RenduMessage = ({ content, monPseudo, isMyMsg = false }) => {
    if (!content) return null;
    const parts = content.split(/(@\w+)/g);
    const hasMention = parts.some(p => p.startsWith('@'));
    if (!hasMention) {
      return (
        <ReactMarkdown components={{
          p: ({node, ...props}) => <p className="mb-1 last:mb-0" {...props} />,
          a: ({node, ...props}) => <a className="underline hover:opacity-80" target="_blank" rel="noopener noreferrer" {...props} />,
          strong: ({node, ...props}) => <strong className="font-extrabold" {...props} />,
          em: ({node, ...props}) => <em className="italic" {...props} />,
          code: ({node, inline, ...props}) => inline ? <code className="bg-black/20 rounded px-1.5 py-0.5 text-sm font-mono" {...props} /> : <pre className="bg-black/30 p-2 rounded-lg my-1 overflow-x-auto"><code className="text-sm font-mono" {...props} /></pre>,
          blockquote: ({node, ...props}) => <blockquote className="border-l-4 border-current pl-3 opacity-80 italic my-2" {...props} />,
        }}>{content}</ReactMarkdown>
      );
    }
    return (
      <p className="text-[15px] break-words">
        {parts.map((part, i) => {
          if (!part.startsWith('@')) return <span key={i}>{part}</span>;
          const mentionned = part.slice(1);
          const estMoi = mentionned === monPseudo;
          return (
            <span key={i} className={`font-bold rounded px-0.5 ${estMoi ? 'bg-warning/40 text-warning-content ring-1 ring-warning/50' : isMyMsg ? 'bg-white/20 text-white' : 'text-primary bg-primary/10'}`}>
              {part}
            </span>
          );
        })}
      </p>
    );
  };

  return (
    <div className="flex flex-1 overflow-hidden relative bg-base-100">
      <style>{`
        @keyframes toastIn { from{opacity:0;transform:translateX(16px) scale(0.95)} to{opacity:1;transform:translateX(0) scale(1)} }
        @keyframes menuAppear { from{opacity:0;transform:scale(0.92) translateY(-6px)} to{opacity:1;transform:scale(1) translateY(0)} }
        @keyframes menuDisappear { from{opacity:1;transform:scale(1) translateY(0)} to{opacity:0;transform:scale(0.92) translateY(-6px)} }
        .menu-contextuel-enter { animation: menuAppear 0.15s cubic-bezier(0.34,1.56,0.64,1) forwards; transform-origin: top left; }
        .menu-contextuel-exit { animation: menuDisappear 0.12s ease-in forwards; transform-origin: top left; }
        @keyframes emojiPop { 0% {opacity:0;transform:scale(0.5) translateY(4px)} 70% {transform:scale(1.15) translateY(-2px)} 100% {opacity:1;transform:scale(1) translateY(0)} }
        .emoji-btn { animation: emojiPop 0.2s ease forwards; }
        @keyframes formatPopIn { 0% {opacity:0; transform:scale(0.9) translateY(4px)} 100% {opacity:1; transform:scale(1) translateY(0)} }
        @keyframes formatPopOut { 0% {opacity:1; transform:scale(1) translateY(0)} 100% {opacity:0; transform:scale(0.9) translateY(4px)} }
        .format-enter { animation: formatPopIn 0.15s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; transform-origin: bottom left; }
        .format-exit { animation: formatPopOut 0.15s ease-in forwards; transform-origin: bottom left; }
      `}</style>
      
      {/* ── SIDEBAR DES SALONS ── */}
      <div className="w-56 bg-base-200 flex flex-col flex-shrink-0 border-r border-base-300">
        
        {/* Header du Serveur */}
        <div className="h-12 px-3 border-b border-base-300 flex items-center justify-between bg-base-200 hover:bg-base-300 transition-colors cursor-pointer" 
             onClick={() => { 
               setOngletInitialSettings(estAdmin ? 'general' : 'membres'); 
               setSettingsOuvert(true); 
             }}>
          <h2 className="font-bold text-sm truncate flex-1">{server.name}</h2>
          <Settings size={14} className="text-gray-400" />
        </div>

        {/* Zone défilante des salons */}
        <div className="flex-1 overflow-y-auto p-2">
          <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider px-2 mb-1 mt-2">Salons textuels</div>
          {channels.map(ch => {
            const isUnread = notifications && notifications[`server-${server.id}-${ch.id}`] > 0;
            const isActive = channelActuel?.id === ch.id;
            return (
              <button 
                key={ch.id} 
                onClick={() => { setChannelActuel(ch); onChannelSelect?.(ch); }}
                className={`cursor-pointer w-full flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-sm transition-colors text-left group
                  ${isActive ? 'bg-base-300 text-base-content font-bold' 
                  : isUnread ? 'text-base-content font-extrabold hover:bg-base-300/50' 
                  : 'text-gray-400 hover:text-base-content hover:bg-base-300/50'}`}
              >
                <Hash size={18} className={`flex-shrink-0 ${isUnread && !isActive ? 'text-base-content' : 'text-gray-400 group-hover:text-base-content'}`} />
                <span className="truncate flex-1">{ch.name}</span>
                {isUnread && !isActive && <span className="w-1.5 h-1.5 bg-base-content rounded-full shadow-sm"></span>}
              </button>
            );
          })}
          {estAdmin && (
            <button onClick={() => { setOngletInitialSettings('channels'); setSettingsOuvert(true); }} 
                    className="w-full flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-sm text-gray-400 hover:text-success hover:bg-base-300/50 transition-colors mt-1">
              <Plus size={16}/><span className="cursor-pointer">Ajouter un salon</span>
            </button>
          )}
        </div>

        {/* Box Profil ancrée en bas */}
        <div className="p-3 border-t border-base-300 bg-base-200 flex items-center gap-2 mt-auto w-full">
          <div className="flex items-center gap-2 flex-1 min-w-0 rounded-lg px-2 py-1.5 group">
            <div className="relative flex-shrink-0">
              <img src={getAvatarUrl(pseudo)} alt="Moi" className="w-8 h-8 rounded-full object-cover" />
              {monProfil?.statut !== 'invisible' && (
                <span className={`w-2.5 h-2.5 absolute -bottom-0.5 -right-0.5 border-2 border-base-200 rounded-full flex-shrink-0 ${
                  monProfil?.statut === 'en_ligne' ? 'bg-success' : 
                  monProfil?.statut === 'occupe' ? 'bg-warning' : 
                  monProfil?.statut === 'absent' ? 'bg-error' : 'bg-gray-400'
                }`} />
              )}
            </div>
            <div className="min-w-0 text-left flex-1">
              <div className="text-sm font-bold truncate">{monProfil?.pseudo || pseudo}</div>
              <div className={`text-[10px] font-medium ${
                monProfil?.statut === 'en_ligne' ? 'text-success' : 
                monProfil?.statut === 'occupe' ? 'text-warning' : 
                monProfil?.statut === 'absent' ? 'text-error' : 'text-gray-400'
              }`}>
                {monProfil?.statut === 'en_ligne' ? 'En ligne' : 
                 monProfil?.statut === 'occupe' ? 'Occupé' : 
                 monProfil?.statut === 'absent' ? 'Absent' : 'Invisible'}
              </div>
            </div>
            <button onClick={onOpenParametres} className="flex-shrink-0 p-1.5 rounded-md text-gray-400 hover:text-base-content hover:bg-base-300 transition-colors cursor-pointer" title="Paramètres">
              <Settings size={16} />
            </button>
          </div>
          <button onClick={onLogout} className="btn btn-ghost btn-sm btn-circle text-error opacity-60 hover:opacity-100 flex-shrink-0" title="Se déconnecter">
            <LogOut size={15} />
          </button>
        </div>
        </div>
        

      {/* ── ZONE PRINCIPALE DU CHAT ── */}
      <div className="flex-1 flex flex-col overflow-hidden">
       {/* Header du salon */}
        <div className="h-12 border-b border-base-200 flex items-center px-4 gap-2 flex-shrink-0 bg-base-100 shadow-sm z-10">
          
          {/* 👇 LE BOUTON BURGER EST ICI 👇 */}
          <button className="md:hidden btn btn-ghost btn-sm btn-circle mr-1" onClick={toggleMenuMobile}>
            <Menu size={20} />
          </button>

          <Hash size={20} className="text-gray-400" />
          <span className="font-bold">{channelActuel?.name || 'Accueil du serveur'}</span>
          <div className="flex-1" />
          
          {/* 👇 BOUTON ÉPINGLES 👇 */}
          {/* 👇 BOUTON ÉPINGLES CORRIGÉ 👇 */}
          <button 
            onClick={() => { setEpinglesPanel(!epinglesPanel); setMembresPanel(false); }} 
            className={`btn btn-ghost btn-sm btn-circle ${epinglesPanel ? 'text-warning bg-warning/10' : 'text-gray-400 hover:text-warning'}`} 
            title="Messages épinglés">
            <Pin size={18}/>
          </button>

          <button 
            onClick={() => { setMembresPanel(!membresPanel); setEpinglesPanel(false); }} 
            className={`btn btn-ghost btn-sm btn-circle ${membresPanel ? 'text-primary bg-primary/10' : 'text-gray-400 hover:text-primary'}`} 
            title="Liste des membres">
            <Users size={18}/>
          </button>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {channelActuel ? (
            <div className="flex-1 flex flex-col overflow-hidden">
                          
            {/* Liste des messages */}
            {/* Liste des messages avec SKELETONS */}
            <div ref={conteneurRef} className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 relative">
              
              {/* 👇 REMPLACE LE LOADER PAR ÇA 👇 */}
              {chargement && messages.length === 0 ? (
                Array(6).fill(0).map((_, i) => <MessageSkeleton key={i} />)
              ) : (
                <>
                  <div className="flex items-center gap-3 my-2 px-2">
                    <div className="flex-1 h-px bg-base-300"></div>
                    <span className="text-[11px] text-gray-400 whitespace-nowrap">Début de l'historique de #{channelActuel?.name}</span>
                    <div className="flex-1 h-px bg-base-300"></div>
                  </div>

                  {messages.map((msg, index) => {
                    const messagePrecedent = index > 0 ? messages[index - 1] : null;
                    const messageParent = msg.reply_to_id ? messages.find(m => m.id === msg.reply_to_id) : null;
                    
                    let auteurTech = msg.username;
                    Object.keys(profilsCache || {}).forEach(k => { if(profilsCache?.[k]?.pseudo === msg.username) auteurTech = k; });
                    const statutAuteur = profilsCache ? getStatutEffectif(auteurTech, profilsCache[auteurTech]) : null;

                    return (
                      <MessageItem
                        key={msg.id}
                        msg={msg}
                        messagePrecedent={messagePrecedent}
                        messageParent={messageParent}
                        monPseudoAffiche={pseudo}
                        statutAuteur={statutAuteur}
                        getAvatarUrlForDisplay={getAvatarUrl}
                        messagesRefsMap={messagesRefsMap}
                        messageEnEdition={messageEnEdition}
                        texteEdition={texteEdition}
                        setTexteEdition={setTexteEdition}
                        sauvegarderModification={sauvegarderEdition}
                        setMessageEnEdition={setMessageEnEdition}
                        ouvrirMenuContextuel={ouvrirMenuContextuel}
                        gererClicProfil={onUserClick}
                        allerAuMessage={allerAuMessage}
                        salonActuel={`server-${server.id}-${channelActuel.id}`}
                        toggleReaction={toggleReaction}
                      />
                    );
                  })}
                </>
              )}
            </div>
            
            {/* ── ZONE DE SAISIE UNIFIÉE ── */}
            <ZoneSaisie
              nouveauMessage={nouveauMessage}
              setNouveauMessage={setNouveauMessage}
              reponseA={reponseA}
              setReponseA={setReponseA}
              fichierPreview={fichierPreview}
              setFichierPreview={setFichierPreview}
              isUploading={isUploading}
              gifOuvert={gifOuvert}
              setGifOuvert={setGifOuvert}
              gifQuery={gifQuery}
              setGifQuery={setGifQuery}
              gifChargement={gifChargement}
              gifResultats={gifResultats}
              gifTendances={gifTendances}
              emojiOuvert={emojiOuvert}
              setEmojiOuvert={setEmojiOuvert}
              showAideFormat={showAideFormat}
              aideFormatFermeture={aideFormatFermeture}
              toggleAideFormat={toggleAideFormat}
              utilisateursEnTrain={utilisateursEnTrain}
              dernierTexteTypingRef={dernierTexteTypingRef}

              /* Variables dynamiques */
              placeholder={`Écrire dans #${channelActuel?.name}...`}
              pseudoActuel={pseudo}

              /* Variables des Mentions */
              mentionMenuOuvert={mentionMenu.ouvert}
              mentionsFiltrees={membresFiltres.map(m => ({ pseudo: m.pseudo, avatar_url: getAvatarUrl(m.pseudo) }))}
              mentionIndex={mentionIndex}
              setMentionIndex={setMentionIndex}
              fermerMenuMention={() => setMentionMenu({ ouvert: false, recherche: '', index: -1 })}
              insererMention={insererMention}

              /* Références et Handlers */
              inputMessageRef={inputMessageRef}
              emojiTriggerRef={emojiTriggerRef}
              fichierInputRef={fichierInputRef}
              gererFrappe={gererFrappe}
              envoyerMessage={envoyerMessage}
              envoyerFichier={envoyerFichier}
              confirmerEnvoiFichier={confirmerEnvoiFichier}
              ouvrirGif={ouvrirGif}
              rechercherGifs={rechercherGifs}
              envoyerGif={envoyerGif}
              insererEmoji={insererEmoji}
            />
          </div>
          ) : !channelsLoaded ? (
            <div className="flex-1 flex flex-col items-center justify-center bg-base-100">
              <Loader2 size={40} className="animate-spin text-primary opacity-50" />
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center bg-base-100 text-center px-4 animate-fade-in">
              <div className="w-24 h-24 bg-base-200 rounded-full flex items-center justify-center mb-6 shadow-inner">
                <Hash size={48} className="text-gray-400 opacity-50" />
              </div>
              <h3 className="text-2xl font-black text-base-content mb-2">C'est un peu vide par ici...</h3>
              <p className="text-gray-500 max-w-md">Il n'y a aucun salon textuel. Créez des salons pour pouvoir discuter avec votre communauté !</p>
            </div>
          )}
          
          {/* Sidebar des membres du serveur (Côté droit) */}
          {/* Sidebar des membres du serveur (Côté droit) */}
          {membresPanel && (
            <PanneauMembres
              membres={membres}
              getAvatarUrl={getAvatarUrl}
              onUserClick={onUserClick}
              profilsCache={profilsCache}
              getStatutEffectif={getStatutEffectif}
            />
          )}
          {/* ── PANNEAU DES MESSAGES ÉPINGLÉS EXTERNALISÉ ── */}
          <PanneauEpingles
            epinglesPanel={epinglesPanel}
            setEpinglesPanel={setEpinglesPanel}
            messages={messagesEpingles}
            getAvatarUrl={getAvatarUrl}
            allerAuMessage={allerAuMessage}
            salonActuel={`server-${server.id}-${channelActuel?.id}`} /* 👈 AJOUTE LE POINT D'INTERROGATION ICI */
            togglePin={togglePin}
            estModerateur={estModerateur}
            pseudo={pseudo}
          />
        </div>
      </div>
      
      {settingsOuvert && (
        <ServerSettings 
          server={server} monRole={monRole} session={session} monProfil={monProfil}
          initialTab={ongletInitialSettings} /* 👈 L'info est bien passée ici */
          onClose={() => setSettingsOuvert(false)} onServerDeleted={onLeave}
          onServerUpdated={(updated) => setServer(updated)} ajouterToast={ajouterToast} />
      )}

      {/* Menu contextuel animé (Clic droit) */}
      {menuContextuel && (
        <div className={`fixed z-[70] bg-base-100 rounded-xl shadow-2xl border border-base-200 py-2 w-52 text-sm overflow-hidden ${menuFermeture ? 'menu-contextuel-exit' : 'menu-contextuel-enter'}`}
          style={{ top: menuContextuel.y, left: menuContextuel.x }}>
          <div className="px-3 pb-2 mb-1 border-b border-base-200 font-bold text-xs text-gray-400 truncate uppercase tracking-wider">{menuContextuel.message.username}</div>
          <div className="flex items-center justify-around px-3 py-2 mb-1 border-b border-base-200">
            {emojisDispos.map((emoji, i) => {
              const live = messages.find(m => m.id === menuContextuel.message.id);
              const dejaReagi = live?.reactions?.some(r => r.username === pseudo && r.emoji === emoji);
              return (
                <button key={emoji} className={`emoji-btn text-xl transition-all duration-100 hover:scale-125 active:scale-95 rounded-lg p-1 ${dejaReagi ? 'bg-primary/15 ring-1 ring-primary/40' : 'hover:bg-base-200'}`}
                  style={{ animationDelay: `${i * 30}ms`, opacity: 0 }}
                  onClick={() => { toggleReaction(menuContextuel.message.id, emoji); fermerMenuContextuel(); }}>{emoji}</button>
              );
            })}
          </div>
          <ul className="menu p-0">
            <li><a onClick={() => { setReponseA(menuContextuel.message); fermerMenuContextuel(); }}><Reply size={16} /> Répondre</a></li>
            
            {/* 👇 NOUVEAU BOUTON ÉPINGLER 👇 */}
            {estModerateur && (
              <li>
                <a onClick={() => { togglePin(menuContextuel.message.id, menuContextuel.message.pinned); fermerMenuContextuel(); }}>
                  <Pin size={16} className={menuContextuel.message.pinned ? "text-warning" : ""} /> 
                  {menuContextuel.message.pinned ? 'Désépingler' : 'Épingler'}
                </a>
              </li>
            )}
            
            {(menuContextuel.message.username === pseudo || estModerateur) && (<>
              {menuContextuel.message.username === pseudo && <li><a onClick={() => { setMessageEnEdition(menuContextuel.message.id); setTexteEdition(menuContextuel.message.content); fermerMenuContextuel(); }}><Pencil size={16} /> Modifier</a></li>}
              <li><a className="text-error hover:bg-error/10 hover:text-error" onClick={() => { supprimerMessage(menuContextuel.message.id); fermerMenuContextuel(); }}><Trash size={16} /> Supprimer</a></li>
            </>)}
          </ul>
        </div>
      )}
    </div>
  );
}