import React from 'react';
import { MessageCircle, ArrowLeft } from 'lucide-react';

export default function LandingPage({
  isTransitioningAuth,
  showAuthForm,
  basculerVersAccueil,
  basculerVersFormulaire,
  isLogin,
  authError,
  email,
  setEmail,
  password,
  setPassword,
  seConnecter,
  sInscrire
}) {
  return (
    <div className="flex h-screen bg-base-100" style={{ fontFamily: "'system-ui', sans-serif" }}>
      {/* ── COLONNE GAUCHE — MARQUE ── */}
      <div className="hidden md:flex w-1/2 bg-base-200 border-r border-base-300 flex-col justify-between p-14">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <MessageCircle size={18} className="text-primary-content" />
          </div>
          <span className="font-bold text-base-content tracking-tight">YoChat</span>
        </div>

        <div>
          <p className="text-3xl font-bold text-base-content leading-snug mb-4">
            Discutez.<br />Créez.<br />Connectez.
          </p>
          <p className="text-sm text-base-content/50 leading-relaxed max-w-xs">
            Messages privés, serveurs communautaires, tout au même endroit.
          </p>
        </div>

        <p className="text-xs text-base-content/30">© {new Date().getFullYear()} YoChat</p>
      </div>

      {/* ── COLONNE DROITE — FORMULAIRE ── */}
      <div className={`flex-1 flex flex-col items-center justify-center px-8 transition-all duration-200 ${isTransitioningAuth ? 'opacity-0 translate-y-2' : 'opacity-100 translate-y-0'}`}>
        
        {/* Logo mobile */}
        <div className="md:hidden flex items-center gap-2 mb-10">
          <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
            <MessageCircle size={16} className="text-primary-content" />
          </div>
          <span className="font-bold text-base-content">YoChat</span>
        </div>

        <div className="w-full max-w-sm">
          {!showAuthForm ? (
            <>
              <h1 className="text-2xl font-bold text-base-content mb-1">Bienvenue</h1>
              <p className="text-sm text-base-content/50 mb-8">Connectez-vous ou créez un compte pour continuer.</p>
              <div className="flex flex-col gap-3">
                <button onClick={() => basculerVersFormulaire(true)}
                  className="btn btn-primary w-full rounded-xl font-semibold">
                  Se connecter
                </button>
                <button onClick={() => basculerVersFormulaire(false)}
                  className="btn btn-ghost w-full rounded-xl font-semibold border border-base-300 hover:border-base-content/20">
                  Créer un compte
                </button>
              </div>
            </>
          ) : (
            <>
              <button onClick={basculerVersAccueil}
                className="flex items-center gap-1.5 text-sm text-base-content/40 hover:text-base-content transition-colors mb-8">
                <ArrowLeft size={14} /> Retour
              </button>

              <h1 className="text-2xl font-bold text-base-content mb-1">
                {isLogin ? 'Connexion' : 'Créer un compte'}
              </h1>
              <p className="text-sm text-base-content/50 mb-8">
                {isLogin ? 'Entrez vos identifiants.' : 'Remplissez les champs ci-dessous.'}
              </p>

              {authError && (
                <div className="mb-4 px-4 py-3 bg-error/10 border border-error/20 rounded-xl text-error text-sm">
                  {authError}
                </div>
              )}

              <form onSubmit={isLogin ? seConnecter : sInscrire} className="flex flex-col gap-4">
                <div>
                  <label className="text-xs font-medium text-base-content/60 mb-1.5 block">Email</label>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                    className="input input-bordered w-full rounded-xl bg-base-200/40 focus:bg-base-100 transition-colors"
                    placeholder="vous@exemple.com" required autoFocus />
                </div>
                <div>
                  <label className="text-xs font-medium text-base-content/60 mb-1.5 block">Mot de passe</label>
                  <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                    className="input input-bordered w-full rounded-xl bg-base-200/40 focus:bg-base-100 transition-colors"
                    placeholder="••••••••" required />
                </div>
                <button type="submit" className="btn btn-primary w-full rounded-xl font-semibold mt-2">
                  {isLogin ? 'Se connecter' : "S'inscrire"}
                </button>
              </form>

              <p className="text-sm text-center text-base-content/40 mt-6">
                {isLogin ? 'Pas encore de compte ?' : 'Déjà un compte ?'}{' '}
                <button onClick={() => basculerVersFormulaire(!isLogin)}
                  className="text-primary hover:underline font-medium">
                  {isLogin ? "S'inscrire" : 'Se connecter'}
                </button>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}