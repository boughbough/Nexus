import React, { useState } from 'react';
import { Upload, Loader2 } from 'lucide-react';
import { supabase } from './supabase';

export default function TabGeneral({ server, onUpdate, ajouterToast }) {
  const [loading, setLoading] = useState(false);
  const [nom, setNom] = useState(server.name);
  const [description, setDescription] = useState(server.description || '');
  const [isPublic, setIsPublic] = useState(server.is_public);
  const [iconPreview, setIconPreview] = useState(server.icon_url);
  const [bannerPreview, setBannerPreview] = useState(server.banner_url);
  const [files, setFiles] = useState({ icon: null, banner: null });

  const sauvegarder = async () => {
    setLoading(true);
    let urls = { icon: server.icon_url, banner: server.banner_url };

    try {
      for (const type of ['icon', 'banner']) {
        if (files[type]) {
          const ext = files[type].name.split('.').pop();
          const path = `servers/${server.id}-${type}-${Date.now()}.${ext}`;
          await supabase.storage.from('avatars').upload(path, files[type]);
          urls[type] = supabase.storage.from('avatars').getPublicUrl(path).data.publicUrl;
        }
      }
      const { error } = await supabase.from('servers').update({ 
        name: nom, description, is_public: isPublic, icon_url: urls.icon, banner_url: urls.banner 
      }).eq('id', server.id);

      if (error) throw error;
      ajouterToast('Serveur mis à jour !');
      onUpdate({ ...server, name: nom, description, is_public: isPublic, icon_url: urls.icon, banner_url: urls.banner });
    } catch (e) {
      ajouterToast(e.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Bannière */}
      <div>
        <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">Bannière</label>
        <label className="cursor-pointer group relative block w-full h-32 rounded-2xl bg-base-200 border-2 border-dashed border-base-300 hover:border-primary overflow-hidden">
          {bannerPreview ? <img src={bannerPreview} className="w-full h-full object-cover" /> : <div className="h-full flex flex-col items-center justify-center text-gray-400"><Upload size={24} /><span className="text-xs">16:9</span></div>}
          <input type="file" className="hidden" onChange={e => { const f=e.target.files[0]; if(f){ setFiles(p=>({...p, banner:f})); setBannerPreview(URL.createObjectURL(f)); }}} />
        </label>
      </div>

      {/* Icône et Nom */}
      <div className="flex gap-4 items-center">
        <label className="cursor-pointer w-20 h-20 rounded-2xl bg-base-200 border border-base-300 flex items-center justify-center overflow-hidden">
          {iconPreview ? <img src={iconPreview} className="w-full h-full object-cover" /> : <span className="text-2xl font-bold">{nom?.[0]}</span>}
          <input type="file" className="hidden" onChange={e => { const f=e.target.files[0]; if(f){ setFiles(p=>({...p, icon:f})); setIconPreview(URL.createObjectURL(f)); }}} />
        </label>
        <div className="flex-1">
          <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">Nom du serveur</label>
          <input className="input input-bordered w-full" value={nom} onChange={e => setNom(e.target.value)} />
        </div>
      </div>

      <div>
        <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">Description</label>
        <textarea className="textarea textarea-bordered w-full" rows={3} value={description} onChange={e => setDescription(e.target.value)} />
      </div>

      <button onClick={sauvegarder} disabled={loading} className="btn btn-primary w-full shadow-lg">
        {loading ? <Loader2 size={18} className="animate-spin"/> : 'Enregistrer'}
      </button>
    </div>
  );
}