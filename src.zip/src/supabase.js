import { createClient } from '@supabase/supabase-js'

// On récupère les variables cachées de manière sécurisée avec Vite
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

// On crée et on exporte notre outil de connexion pour pouvoir l'utiliser partout !
export const supabase = createClient(supabaseUrl, supabaseAnonKey)